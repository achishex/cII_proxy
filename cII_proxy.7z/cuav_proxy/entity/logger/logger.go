package logger

import (
	"fmt"
	"log"
	"os"
	"path/filepath"
	"runtime"
	"sync"
)

// Logger ...
type Logger struct {
	logger *log.Logger
}

var (
	loggerInstance *Logger
	once           sync.Once
)

// Instance 获取日志实例
func Instance() *Logger {
	once.Do(func() {
		loggerInstance = &Logger{
			logger: log.New(os.Stdout, "", log.Ldate|log.Ltime|log.Lmicroseconds),
		}
		loggerInstance.logger.SetFlags(log.Ldate | log.Ltime | log.Lmicroseconds)
	})
	return loggerInstance
}

// Printf 定义打印函数
func (l *Logger) Printf(format string, v ...any) {
	_, file, line, _ := runtime.Caller(1)
	msg := fmt.Sprintf(format, v...)
	prefix := fmt.Sprintf("[%s:%d]", filepath.Base(file), line)
	message := prefix + msg
	l.logger.Printf(message)
}
