package entity

// DeviceType 设备类型
type DeviceType uint8

const (
	// DEV_AEAG 反制枪
	DEV_AEAG DeviceType = 1
	// DEV_SCREEN 屏幕
	DEV_SCREEN DeviceType = 2
	// DEV_RADAR 雷达
	DEV_RADAR DeviceType = 3
	// DEV_PC 电脑
	DEV_PC DeviceType = 4
	// DEV_C2_BLE C2 蓝牙
	DEV_C2_BLE DeviceType = 5
	// DEV_C2_WIFI C2 WiFi
	DEV_C2_WIFI DeviceType = 6
	// DEV_V2DRONEID C2 droneID
	DEV_V2DRONEID DeviceType = 7
	// DEV_RF  360D
	DEV_RF DeviceType = 8
	// DEV_SPOOFER DEV_NSF4000
	DEV_SPOOFER DeviceType = 9
	// DEV_SFL100 SFL100
	DEV_SFL100 DeviceType = 11
	//C2_AGX_雷达融合平台
	DEV_AGX DeviceType = 12

	// DEV_FPV DEV FPV
	DEV_FPV DeviceType = 23

	// DEV_BROADCAST 广播模式
	DEV_BROADCAST DeviceType = 255
)
const (
	MaxReceiveSize = 1024
)

const (
	DevOnline  = 0 //设备在线
	DevOffline = 1 //设备离线
)

const (
	DeviceDisenable = 2 //设备禁用
	DeviceEnable    = 1 //设备启用
)

const (
	ProtoTypeSlink = 1
	ProtoTypeJson  = 2
	ProtoTypeProto = 3
)

// CtxKey ...
type CtxKey string

const (
	// UDPAddrCxtKey 远程IP地址
	UDPAddrCxtKey CtxKey = "UdpRemoteAddr"
	// PacketHeadCxtKey 包头
	PacketHeadCxtKey CtxKey = "PacketHead"
	// ProtoTypeCxtKey 协议类型
	ProtoTypeCxtKey CtxKey = "ProtoType"
)
