//go:build linux || android || windows

package iphelper

import (
	"reflect"
	"testing"
)

func TestGetLocalIPInfos(t *testing.T) {
	tests := []struct {
		name    string
		want    []IPInfo
		wantErr bool
	}{
		{
			name: "Case1",
			want: []IPInfo{
				{
					LocalIP:     "10.240.34.11",
					BroadCastIP: "10.240.34.255",
				},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := GetLocalIPInfos()
			if (err != nil) != tt.wantErr {
				t.Errorf("GetLocalIPInfos() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("GetLocalIPInfos() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestMatchLocalIP(t *testing.T) {
	type args struct {
		ip string
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		{
			name: "Case1",
			args: args{
				ip: "10.240.34.45",
			},
			want: "10.240.34.11",
		},
		{
			name: "Case1",
			args: args{
				ip: "10.240.36.45",
			},
			want: "",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := MatchLocalIP(tt.args.ip); got != tt.want {
				t.Errorf("MatchLocalIP() = %v, want %v", got, tt.want)
			}
		})
	}
}
