package api

import (
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/generatecode/golang/bizproto"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/msgid"
	"net/http"

	"adasgitlab.autel.com/tools/cuav_proxy/entity/entity"
	"adasgitlab.autel.com/tools/cuav_proxy/entity/logger"
	_ "adasgitlab.autel.com/tools/cuav_proxy/logic/report"
	_ "adasgitlab.autel.com/tools/cuav_proxy/logic/response"
	"adasgitlab.autel.com/tools/cuav_proxy/rpc/devicerpc"
	"adasgitlab.autel.com/tools/cuav_proxy/rpc/webclient"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/gorilla/websocket"
)

// // Result 响应结果
// type Result struct {
// 	Code int    `json:"code"` //错误码
// 	Msg  string `json:"msg"`  //错误信息
// }

// // Response 响应信息
// type Response struct {
// 	Result Result `json:"result"` //业务结果
// 	Data   any    `json:"data"`   //业务数据
// }

func SuccessResponse(data any) *Response {
	return &Response{Result: Result{Code: 0, Msg: "Success"}, Data: data}
}
func ErrorResponse(code int, msg string) *Response {
	return &Response{Result: Result{Code: code, Msg: msg}}
}

//radar v2 websocket interface

// 雷达 websocket接口服务，
// 返回值为json格式：{"type":"xxx", "data": {xxx} }
// type 为 data的数据类型
func RadarWs(c *gin.Context) {
	upgrader := websocket.Upgrader{
		CheckOrigin: func(r *http.Request) bool { return true },
	}
	conn, err := upgrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		logger.Instance().Printf("Failed to upgrade to websocket err %v", err)
		return
	}
	logger.Instance().Printf("websocket conn remote ip: %s", conn.RemoteAddr().String())
	client := webclient.NewClient(webclient.WithConn(conn), webclient.WithClientID(uuid.New().String()))
	if err := webclient.ClientMgrInstance().Register(client); err != nil {
		logger.Instance().Printf("devi websocket store err %v", err)
		return
	}
	go client.Read()
	go client.Write()
}

// radar v2 http interface
func SetBeamScheduling(c *gin.Context) {
	res := Response{
		Result: Result{
			Code: 0,
			Msg:  "Success",
		},
	}
	type reqStruct struct {
		Sn   string                              `json:"sn"`
		Data *bizproto.RadarSetBeamSchedulingReq `json:"data"`
	}
	req := &reqStruct{}
	if err := c.ShouldBindJSON(req); err != nil {
		c.JSON(400, ErrorResponse(-1001, err.Error()))
		return
	}

	deviceRsp, err := devicerpc.CallV2(req.Sn, entity.DEV_RADAR, msgid.RadarIdV2SetBeamScheduling, req.Data)
	if err != nil {
		logger.Instance().Printf("GetRadarSystemInfo rpc call err %v", err)
		c.JSON(500, ErrorResponse(-1002, err.Error()))
		return
	}
	result, ok := deviceRsp.(*bizproto.RadarSetBeamSchedulingRsp)
	if !ok {
		logger.Instance().Printf("convert TracerGetWorkModeResponse err")
		c.JSON(500, ErrorResponse(-1003, err.Error()))
		return
	}
	res.Data = bizproto.RadarSetRsp{
		Status: result.Status,
	}
	c.JSON(200, res)
}

func SetRadarConfig(c *gin.Context) {
	res := Response{
		Result: Result{
			Code: 0,
			Msg:  "Success",
		},
	}
	type reqStruct struct {
		Sn   string                   `json:"sn"`
		Data *bizproto.RadarConfigReq `json:"data"`
	}
	req := &reqStruct{}
	if err := c.ShouldBindJSON(req); err != nil {
		c.JSON(400, ErrorResponse(-1001, err.Error()))
		return
	}

	deviceRsp, err := devicerpc.CallV2(req.Sn, entity.DEV_RADAR, msgid.RadarIdV2SetConfig, req.Data)
	if err != nil {
		logger.Instance().Printf("GetRadarSystemInfo rpc call err %v", err)
		c.JSON(500, ErrorResponse(-1002, err.Error()))
		return
	}
	result, ok := deviceRsp.(*bizproto.RadarConfigRsp)
	if !ok {
		logger.Instance().Printf("convert TracerGetWorkModeResponse err")
		c.JSON(500, ErrorResponse(-1003, err.Error()))
		return
	}
	res.Data = bizproto.RadarSetRsp{
		Status: result.Status,
	}
	c.JSON(200, res)
}

// radar v2 http interface
func SetRadarSetting(c *gin.Context) {
	res := Response{
		Result: Result{
			Code: 0,
			Msg:  "Success",
		},
	}
	type reqStruct struct {
		Sn   string                `json:"sn"`
		Data *bizproto.RadarSetReq `json:"data"`
	}
	req := &reqStruct{}
	if err := c.ShouldBindJSON(req); err != nil {
		c.JSON(400, ErrorResponse(-1001, err.Error()))
		return
	}

	deviceRsp, err := devicerpc.CallV2(req.Sn, entity.DEV_RADAR, msgid.RadarIdV2SetSetting, req.Data)
	if err != nil {
		logger.Instance().Printf("GetRadarSystemInfo rpc call err %v", err)
		c.JSON(500, ErrorResponse(-1002, err.Error()))
		return
	}
	result, ok := deviceRsp.(*bizproto.RadarSetRsp)
	if !ok {
		logger.Instance().Printf("convert TracerGetWorkModeResponse err")
		c.JSON(500, ErrorResponse(-1003, err.Error()))
		return
	}
	res.Data = bizproto.RadarSetRsp{
		Status: result.Status,
	}
	c.JSON(200, res)
}

// msgid = 0x3E	设置雷达姿态
func SetRadarAttitudeLLA(c *gin.Context) {
	res := Response{
		Result: Result{
			Code: 0,
			Msg:  "Success",
		},
	}
	type reqStruct struct {
		Sn   string                           `json:"sn"`
		Data *bizproto.RadarSetAttitudeLLAReq `json:"data"`
	}
	req := &reqStruct{}
	if err := c.ShouldBindJSON(req); err != nil {
		c.JSON(400, ErrorResponse(-1001, err.Error()))
		return
	}

	deviceRsp, err := devicerpc.CallV2(req.Sn, entity.DEV_RADAR, msgid.RadarIdV2SetAttitudeLLA, req.Data)
	if err != nil {
		logger.Instance().Printf("GetRadarSystemInfo rpc call err %v", err)
		c.JSON(500, ErrorResponse(-1002, err.Error()))
		return
	}
	result, ok := deviceRsp.(*bizproto.RadarSetAttitudeLLARsp)
	if !ok {
		logger.Instance().Printf("convert TracerGetWorkModeResponse err")
		c.JSON(500, ErrorResponse(-1003, err.Error()))
		return
	}
	res.Data = bizproto.RadarSetAttitudeLLARsp{
		Status: result.Status,
	}
	c.JSON(200, res)
}

//
//// TracerSetHide 设置tracer 隐蔽模式
//func TracerSetHide(c *gin.Context) {
//	res := Response{
//		Result: Result{
//			Code: 0,
//			Msg:  "Success",
//		},
//	}
//	req := &client.TracerSetHideModeRequest{}
//	if err := c.ShouldBindJSON(req); err != nil {
//		res.Result.Code = -1001
//		res.Result.Msg = err.Error()
//		c.JSON(400, res)
//		return
//	}
//	devicreq := &slinkv1.TracerSetHideModeRequest{
//		HideMode: uint8(req.HideMode),
//	}
//
//	deviceRsp, err := devicerpc.Call(req.GetSn(), entity.DEV_V2DRONEID, slinkv1.TracerSetHideMode, devicreq)
//	if err != nil {
//		logger.Instance().Printf("GetRadarSystemInfo rpc call err %v", err)
//		res.Result.Code = -1002
//		res.Result.Msg = err.Error()
//		c.JSON(500, res)
//		return
//	}
//	result, ok := deviceRsp.(*slinkv1.TracerSetHideModeResult)
//	if !ok {
//		logger.Instance().Printf("convert TracerSetHideModeResponse err")
//		res.Result.Code = -1003
//		res.Result.Msg = "convert TracerSetHideModeResponse err"
//		c.JSON(500, res)
//		return
//	}
//	res.Data = client.TracerSetHideModeResponse{
//		Status: int32(result.Status),
//	}
//	c.JSON(200, res)
//}
