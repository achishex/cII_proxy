package api

import (
	"encoding/hex"
	"net/http"
	"reflect"

	"strings"

	"adasgitlab.autel.com/tools/cuav_proxy/entity/entity"
	"adasgitlab.autel.com/tools/cuav_proxy/entity/logger"
	_ "adasgitlab.autel.com/tools/cuav_proxy/logic/report"
	_ "adasgitlab.autel.com/tools/cuav_proxy/logic/response"
	"adasgitlab.autel.com/tools/cuav_proxy/proto/client"
	"adasgitlab.autel.com/tools/cuav_proxy/rpc/devicerpc"
	"adasgitlab.autel.com/tools/cuav_proxy/rpc/webclient"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/gorilla/websocket"
)

// Result 响应结果
type Result struct {
	Code int    `json:"code"` //错误码
	Msg  string `json:"msg"`  //错误信息
}

// Response 响应信息
type Response struct {
	Result Result `json:"result"` //业务结果
	Data   any    `json:"data"`   //业务数据
}

// SetTracerWorkMode ...
func SetTracerWorkMode(c *gin.Context) {
	res := Response{
		Result: Result{
			Code: 0,
			Msg:  "Success",
		},
	}
	req := &client.TracerSetOrientationModeRequest{}
	if err := c.ShouldBindJSON(req); err != nil {
		res.Result.Code = -1001
		res.Result.Msg = err.Error()
		c.JSON(400, res)
		return
	}
	devicreq := &slinkv1.TracerSetOrientationModeRequest{
		Status:    uint8(req.Status),
		UavNumber: uint8(req.UavNumber),
		DroneName: func(name string) [25]byte {
			tmp := [25]byte{}
			copy(tmp[:], name)
			return tmp
		}(req.GetDroneName()),
		UFreq: uint32(req.UFreq),
	}
	logger.Instance().Printf("SetTracerWorkMode devicreq %+v", devicreq)
	deviceRsp, err := devicerpc.Call(req.GetSn(), entity.DEV_V2DRONEID, slinkv1.TracerSetOrientationMode, devicreq)
	if err != nil {
		logger.Instance().Printf("SetTracerWorkMode rpc call err %v", err)
		res.Result.Code = -1002
		res.Result.Msg = err.Error()
		c.JSON(500, res)
		return
	}
	result, ok := deviceRsp.(*slinkv1.TracerSetOrientationModeResponse)
	if !ok {
		logger.Instance().Printf("convert TracerSetOrientationModeResponse err")
		res.Result.Code = -1003
		res.Result.Msg = "convert TracerSetOrientationModeResponse err"
		c.JSON(500, res)
		return
	}
	res.Data = client.TracerSetOrientationModeResponse{
		Status: int32(result.Status),
	}
	c.JSON(200, res)
}

// GetRadarSystemInfo 查询雷达系统信息
func GetRadarSystemInfo(c *gin.Context) {
	res := Response{
		Result: Result{
			Code: 0,
			Msg:  "Success",
		},
	}
	req := &client.GetSystemInfoRequest{}
	if err := c.ShouldBindJSON(req); err != nil {
		res.Result.Code = -1001
		res.Result.Msg = err.Error()
		c.JSON(400, res)
		return
	}
	devicreq := &slinkv1.RadarGetSystemInfoRequest{
		DataType: uint8(req.GetDataType()),
	}
	deviceRsp, err := devicerpc.Call(req.GetSn(), entity.DEV_RADAR, slinkv1.RadarIdGetSystemInfo, devicreq)
	if err != nil {
		logger.Instance().Printf("GetRadarSystemInfo rpc call err %v", err)
		res.Result.Code = -1002
		res.Result.Msg = err.Error()
		c.JSON(500, res)
		return
	}
	result, ok := deviceRsp.(*slinkv1.RadarGetSystemInfoResponse)
	if !ok {
		logger.Instance().Printf("convert RadarGetSystemInfoResponse err")
		res.Result.Code = -1003
		res.Result.Msg = "convert RadarGetSystemInfoResponse err"
		c.JSON(500, res)
		return
	}
	res.Data = client.GetSystemInfoResponse{
		DataType: int32(result.DataType),
		Value: func(data [16]byte) string {
			return strings.TrimRight(string(data[:]), string(rune(0)))
		}(result.DataValue),
	}
	c.JSON(200, res)
}

// SetRadarSystemInfo 设置雷达系统信息
func SetRadarSystemInfo(c *gin.Context) {
	res := Response{
		Result: Result{
			Code: 0,
			Msg:  "Success",
		},
	}
	req := &client.SetSystemStatusRequest{}
	if err := c.ShouldBindJSON(req); err != nil {
		res.Result.Code = -1001
		res.Result.Msg = err.Error()
		c.JSON(400, res)
		return
	}
	devicreq := &slinkv1.RadarSetSystemStatusReq{
		StatusType: uint8(req.Status),
		WorkMode:   uint8(req.WorkMode),
	}
	deviceRsp, err := devicerpc.Call(req.GetSn(), entity.DEV_RADAR, slinkv1.RadarIdSetSystemStatus, devicreq)
	if err != nil {
		logger.Instance().Printf("GetRadarSystemInfo rpc call err %v", err)
		res.Result.Code = -1002
		res.Result.Msg = err.Error()
		c.JSON(500, res)
		return
	}
	result, ok := deviceRsp.(*slinkv1.RadarSetSystemStatusResponse)
	if !ok {
		logger.Instance().Printf("convert RadarGetSystemInfoResponse err")
		res.Result.Code = -1003
		res.Result.Msg = "convert RadarGetSystemInfoResponse err"
		c.JSON(500, res)
		return
	}
	res.Data = client.SetSystemStatusResponse{
		Status: int32(result.Status),
	}
	c.JSON(200, res)
}

// ReportDeviceInfo 上报设备信息
func ReportDeviceInfo(c *gin.Context) {
	upgrader := websocket.Upgrader{
		CheckOrigin: func(r *http.Request) bool { return true },
	}
	conn, err := upgrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		logger.Instance().Printf("Failed to upgrade to websocket err %v", err)
		return
	}
	logger.Instance().Printf("websocket conn remote ip: %s", conn.RemoteAddr().String())
	client := webclient.NewClient(webclient.WithConn(conn), webclient.WithClientID(uuid.New().String()))
	if err := webclient.ClientMgrInstance().Register(client); err != nil {
		logger.Instance().Printf("devi websocket store err %v", err)
		return
	}
	go client.Read()
	go client.Write()
}

// GetTracerWorkMode  获取trace工作模式
func GetTracerWorkMode(c *gin.Context) {
	res := Response{
		Result: Result{
			Code: 0,
			Msg:  "Success",
		},
	}
	req := &client.TracerGetWorkModeRequest{}
	if err := c.ShouldBindJSON(req); err != nil {
		res.Result.Code = -1001
		res.Result.Msg = err.Error()
		c.JSON(400, res)
		return
	}

	devicreq := &slinkv1.TracerGetWorkModeRequest{}

	deviceRsp, err := devicerpc.Call(req.GetSn(), entity.DEV_V2DRONEID, slinkv1.TracerGetWorkMode, devicreq)
	if err != nil {
		logger.Instance().Printf("GetTracerWorkMode rpc call err %v", err)
		res.Result.Code = -1002
		res.Result.Msg = err.Error()
		c.JSON(500, res)
		return
	}
	result, ok := deviceRsp.(*slinkv1.TracerGetWorkModeResponse)
	if !ok {
		logger.Instance().Printf("convert GetTracerWorkMode err")
		res.Result.Code = -1003
		res.Result.Msg = "convert GetTracerWorkMode err"
		c.JSON(500, res)
		return
	}
	res.Data = client.TracerGetWorkModeResponse{
		Status: int32(result.Status),
	}
	c.JSON(200, res)
}

// TracerWhiteList  获取trace工作模式
func TracerWhiteList(c *gin.Context) {
	res := Response{
		Result: Result{
			Code: 0,
			Msg:  "Success",
		},
	}
	req := &client.TracerSetWhiteRequest{}
	if err := c.ShouldBindJSON(req); err != nil {
		res.Result.Code = -1001
		res.Result.Msg = err.Error()
		c.JSON(400, res)
		return
	}
	var sns []slinkv1.TracerWhiteInfo
	for _, v := range req.SerialNum {
		var tempSn [32]byte
		copy(tempSn[:], v)
		sns = append(sns, slinkv1.TracerWhiteInfo{Serial: tempSn})
	}
	devicreq := &slinkv1.TracerSetWhiteRequest{
		WhiteNum:  uint16(req.TotalNum),
		WhiteList: sns,
	}

	deviceRsp, err := devicerpc.Call(req.GetSn(), entity.DEV_V2DRONEID, slinkv1.TracerSetWhiteList, devicreq)
	if err != nil {
		logger.Instance().Printf("TracerWhiteList rpc call err %v", err)
		res.Result.Code = -1002
		res.Result.Msg = err.Error()
		c.JSON(500, res)
		return
	}
	result, ok := deviceRsp.(*slinkv1.TracerWhiteListResult)
	if !ok {
		logger.Instance().Printf("convert TracerWhiteList err")
		res.Result.Code = -1003
		res.Result.Msg = "convert TracerWhiteList err"
		c.JSON(500, res)
		return
	}
	res.Data = client.TracerSetWhiteRespone{
		Status: uint32(result.Status),
	}
	c.JSON(200, res)
}

// TracerSetAlarm tracer/set-alarm
func TracerSetAlarm(c *gin.Context) {
	res := Response{
		Result: Result{
			Code: 0,
			Msg:  "Success",
		},
	}
	req := &client.TracerSetAlarmRequest{}
	if err := c.ShouldBindJSON(req); err != nil {
		res.Result.Code = -1001
		res.Result.Msg = err.Error()
		c.JSON(400, res)
		return
	}

	devicreq := &slinkv1.TracerSetAlarmRequest{
		Alarm: uint8(req.Alarm),
	}

	deviceRsp, err := devicerpc.Call(req.GetSn(), entity.DEV_V2DRONEID, slinkv1.TracerSetAlarmLevel, devicreq)
	if err != nil {
		logger.Instance().Printf("TracerSetAlarm rpc call err %v", err)
		res.Result.Code = -1002
		res.Result.Msg = err.Error()
		c.JSON(500, res)
		return
	}
	result, ok := deviceRsp.(*slinkv1.TracerAlarmModeResult)
	if !ok {
		logger.Instance().Printf("TracerSetAlarm type of deviceRsp : %+v", reflect.TypeOf(deviceRsp))
		logger.Instance().Printf("convert TracerSetAlarm err")
		res.Result.Code = -1003
		res.Result.Msg = "convert TracerSetAlarm err"
		c.JSON(500, res)
		return
	}
	res.Data = client.TracerSetAlarmResponse{
		Status: int32(result.Status),
	}
	c.JSON(200, res)
}

// TracerSetHide 设置tracer 隐蔽模式
func TracerSetHide(c *gin.Context) {
	res := Response{
		Result: Result{
			Code: 0,
			Msg:  "Success",
		},
	}
	req := &client.TracerSetHideModeRequest{}
	if err := c.ShouldBindJSON(req); err != nil {
		res.Result.Code = -1001
		res.Result.Msg = err.Error()
		c.JSON(400, res)
		return
	}
	devicreq := &slinkv1.TracerSetHideModeRequest{
		HideMode: uint8(req.HideMode),
	}

	deviceRsp, err := devicerpc.Call(req.GetSn(), entity.DEV_V2DRONEID, slinkv1.TracerSetHideMode, devicreq)
	if err != nil {
		logger.Instance().Printf("GetRadarSystemInfo rpc call err %v", err)
		res.Result.Code = -1002
		res.Result.Msg = err.Error()
		c.JSON(500, res)
		return
	}
	result, ok := deviceRsp.(*slinkv1.TracerSetHideModeResult)
	if !ok {
		logger.Instance().Printf("convert TracerSetHideModeResponse err")
		res.Result.Code = -1003
		res.Result.Msg = "convert TracerSetHideModeResponse err"
		c.JSON(500, res)
		return
	}
	res.Data = client.TracerSetHideModeResponse{
		Status: int32(result.Status),
	}
	c.JSON(200, res)
}

func StringToHexByte(data string) []byte {
	if len(data) <= 0 {
		return []byte{}
	}
	ret, e := hex.DecodeString(strings.ToLower(data))
	if e == nil {
		return ret
	}
	return []byte{}
}

// TracerProSetOrient tracerPro 设置定向命令
func TracerProSetOrient(c *gin.Context) {
	res := Response{
		Result: Result{
			Code: 0,
			Msg:  "Success",
		},
	}
	req := &client.TracerProSetOrientRequest{}
	if err := c.ShouldBindJSON(req); err != nil {
		res.Result.Code = -1001
		res.Result.Msg = err.Error()
		c.JSON(400, res)
		return
	}

	var tmpWifiMac [6]byte
	copy(tmpWifiMac[:], StringToHexByte(req.GetWifiMac()))

	devicreq := &slinkv1.TracerProSetOrientRequest{
		Status:    uint8(req.GetStatus()),
		UavNumber: uint16(req.GetUavNumber()),
		WifiMac:   tmpWifiMac,             // Mac地址
		UFreq:     uint32(req.GetUFreq()), // LSB 无人机信号频率(mHz)
	}

	deviceRsp, err := devicerpc.Call(req.GetSn(), entity.DEV_V2DRONEID, slinkv1.TracerProSetOrient, devicreq)
	if err != nil {
		logger.Instance().Printf("TracerProSetOrient rpc call err %v", err)
		res.Result.Code = -1002
		res.Result.Msg = err.Error()
		c.JSON(500, res)
		return
	}
	result, ok := deviceRsp.(*slinkv1.TracerProSetOrientResponse)
	if !ok {
		logger.Instance().Printf("convert TracerProSetOrientResponse err")
		res.Result.Code = -1003
		res.Result.Msg = "convert TracerProSetOrientResponse err"
		c.JSON(500, res)
		return
	}

	var ret = 1
	if result.Status == 0 { //fail
		ret = 2
	}
	res.Data = client.TracerProSetOrientResponse{
		Status: int32(ret),
	}
	c.JSON(200, res)
}

// TracerSetVideoParam 设置视频参数
func TracerSetVideoParam(c *gin.Context) {
	res := Response{
		Result: Result{
			Code: 0,
			Msg:  "Success",
		},
	}
	req := &client.TracerSetVideoParamRequest{}
	if err := c.ShouldBindJSON(req); err != nil {
		res.Result.Code = -1001
		res.Result.Msg = err.Error()
		c.JSON(400, res)
		return
	}

	devicreq := &slinkv1.TracerSetVideParamRequest{
		FreqOffset: req.GetFreqOffset(),
		Reserve:    req.GetReserve(),
	}

	deviceRsp, err := devicerpc.Call(req.GetSn(), entity.DEV_V2DRONEID, slinkv1.TracerSetVideoParam, devicreq)
	if err != nil {
		logger.Instance().Printf("TracerSetVideoParam rpc call err %v", err)
		res.Result.Code = -1002
		res.Result.Msg = err.Error()
		c.JSON(500, res)
		return
	}
	result, ok := deviceRsp.(*slinkv1.TracerSetVideParamResponse)
	if !ok {
		logger.Instance().Printf("convert TracerSetVideParamResponse err")
		res.Result.Code = -1003
		res.Result.Msg = "convert TracerSetVideParamResponse err"
		c.JSON(500, res)
		return
	}

	var ret = 1
	if result.Status == 0 { //fail
		ret = 2
	}
	res.Data = client.TracerSetVideoParamResponse{
		Status: int32(ret),
	}
	c.JSON(200, res)
}

// TracerSetNoiseFloor 设置噪底
func TracerSetNoiseFloor(c *gin.Context) {
	res := Response{
		Result: Result{
			Code: 0,
			Msg:  "Success",
		},
	}
	req := &client.TracerSetNoiseFloorRequest{}
	if err := c.ShouldBindJSON(req); err != nil {
		res.Result.Code = -1001
		res.Result.Msg = err.Error()
		c.JSON(400, res)
		return
	}

	devicreq := &slinkv1.TracerSetBaseNoiseRequest{
		Freq: uint32(req.GetFreq()),
	}

	deviceRsp, err := devicerpc.Call(req.GetSn(), entity.DEV_V2DRONEID, slinkv1.TracerSetNoiseFloor, devicreq)
	if err != nil {
		logger.Instance().Printf("TracerSetNoiseFloorRequest rpc call err %v", err)
		res.Result.Code = -1002
		res.Result.Msg = err.Error()
		c.JSON(500, res)
		return
	}
	result, ok := deviceRsp.(*slinkv1.TracerSetBaseNoiseResponse)
	if !ok {
		logger.Instance().Printf("convert TracerSetBaseNoiseResponse err")
		res.Result.Code = -1003
		res.Result.Msg = "convert TracerSetBaseNoiseResponse err"
		c.JSON(500, res)
		return
	}

	var ret = 1
	if result.Status == 0 { //fail
		ret = 2
	}
	res.Data = client.TracerSetNoiseFloorResponse{
		Status: int32(ret),
	}
	c.JSON(200, res)
}

// TracerSendCmd 向tracer发送CMD命令
func TracerSendCmd(c *gin.Context) {
	res := Response{
		Result: Result{
			Code: 0,
			Msg:  "Success",
		},
	}
	req := &client.TracerCliRequest{}
	if err := c.ShouldBindJSON(req); err != nil {
		res.Result.Code = -1001
		res.Result.Msg = err.Error()
		c.JSON(400, res)
		return
	}

	devicreq := &slinkv1.TracerCliRequest{
		Handle: 1,
		Cmd:    append([]byte(req.GetCmd())),
	}

	deviceRsp, err := devicerpc.Call(req.GetSn(), entity.DEV_V2DRONEID, slinkv1.TracerCliSend, devicreq)
	if err != nil {
		logger.Instance().Printf("TracerCliRequest rpc call err %v", err)
		res.Result.Code = -1002
		res.Result.Msg = err.Error()
		c.JSON(500, res)
		return
	}
	result, ok := deviceRsp.(*slinkv1.TracerCliResponse)
	if !ok {
		logger.Instance().Printf("convert TracerCliResponse err")
		res.Result.Code = -1003
		res.Result.Msg = "convert TracerCliResponse err"
		c.JSON(500, res)
		return
	}

	var ret = 1
	if result.CmdParseRetcode < 0 || result.CmdExecRetcode != 0 { //fail
		ret = 2
	}
	res.Data = client.TracerSetNoiseFloorResponse{
		Status: int32(ret),
	}
	c.JSON(200, res)
	return
}
