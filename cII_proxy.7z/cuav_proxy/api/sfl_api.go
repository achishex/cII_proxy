package api

import (
	"adasgitlab.autel.com/tools/cuav_proxy/entity/entity"
	"adasgitlab.autel.com/tools/cuav_proxy/entity/logger"
	"adasgitlab.autel.com/tools/cuav_proxy/proto/client"
	"adasgitlab.autel.com/tools/cuav_proxy/rpc/devicerpc"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
	"errors"
	"fmt"
	"github.com/gin-gonic/gin"
)

// SflHitAngle 设置打击点信息
func SflHitAngle(c *gin.Context) {
	res := Response{
		Result: Result{
			Code: 0,
			Msg:  "Success",
		},
	}
	req := &client.SflHitAngleRequest{}
	if err := c.ShouldBindJSON(req); err != nil {
		res.Result.Code = -1001
		res.Result.Msg = err.Error()
		c.JSON(400, res)
		return
	}
	fmt.Println("receive SflHitAngleRequest")
	devicreq := &slinkv1.SflSetHitInfoRequest{
		HitCnt:    2,
		HitTime1:  uint8(req.HitTime),
		HitPitch1: uint8(req.HitPitchBegin),
		HitTime2:  uint8(req.HitTime),
		HitPitch2: uint8(req.HitPitchEnd),
	}

	deviceRsp, err := devicerpc.Call(req.GetSn(), entity.DEV_SFL100, slinkv1.SflSetPith, devicreq)
	if err != nil {
		logger.Instance().Printf("SflSetHitInfoRequest rpc call err %v", err)
		res.Result.Code = -1002
		res.Result.Msg = err.Error()
		c.JSON(500, res)
		return
	}
	result, ok := deviceRsp.(*slinkv1.SflSetHitInfoResponse)
	if !ok {
		logger.Instance().Printf("convert SflSetHitInfoResponse err")
		res.Result.Code = -1003
		res.Result.Msg = "convert SflSetHitInfoResponse err"
		c.JSON(500, res)
		return
	}
	fmt.Println("convert SflSetHitInfoResponse")
	var ret = 1
	if result.Status == 0 { //fail
		ret = 2
	}

	devicreq2 := &slinkv1.SflSetHitAngleRequest{
		HitAngleBegin: uint16(req.HitAngleBegin),
		HitAngleEnd:   uint16(req.HitAngleEnd),
	}

	deviceRsp2, err := devicerpc.Call(req.GetSn(), entity.DEV_SFL100, slinkv1.SflSetAngle, devicreq2)
	if err != nil {
		logger.Instance().Printf("SflSetHitAngleRequest rpc call err %v", err)
		res.Result.Code = -1002
		res.Result.Msg = err.Error()
		c.JSON(500, res)
		return
	}
	result2, ok := deviceRsp2.(*slinkv1.SflSetHitAngleResponse)
	if !ok {
		logger.Instance().Printf("convert SflSetHitAngleResponse err")
		res.Result.Code = -1003
		res.Result.Msg = "convert SflSetHitAngleResponse err"
		c.JSON(500, res)
		return
	}

	if result2.Status == 0 { //fail
		ret = 2
	}
	res.Data = client.SflHitAngleResponse{
		Status: int32(ret),
	}
	c.JSON(200, res)
}

func SflHorizontalTurn(c *gin.Context) {

	res := Response{
		Result: Result{
			Code: 0,
			Msg:  "Success",
		},
	}
	req := &client.SflHorizontalTurnRequest{}
	if err := c.ShouldBindJSON(req); err != nil {
		res.Result.Code = -1001
		res.Result.Msg = err.Error()
		c.JSON(400, res)
		return
	}
	logger.Instance().Printf("convert SflHorizontalTurnRequest, req:%v", req)
	var tempTurn uint8

	if req.StartStopTurn == 1 {
		tempTurn = 1
	} else if req.StartStopTurn == 2 {
		tempTurn = 0
	} else {
		res.Result.Code = -1001
		res.Result.Msg = errors.New("StartStopTurn is invalid").Error()
		c.JSON(400, res)
		return
	}
	devicreq := &slinkv1.SflHorizontalTurnRequest{
		StartStop: tempTurn,
		Direction: uint8(req.Direction),
		Angle:     uint16(req.Angle),
		Speed:     uint16(req.Speed),
	}

	deviceRsp, err := devicerpc.Call(req.GetSn(), entity.DEV_SFL100, slinkv1.SflHorizontalTurn, devicreq)
	if err != nil {
		logger.Instance().Printf("SflHorizontalTurnRequest rpc call err %v", err)
		res.Result.Code = -1002
		res.Result.Msg = err.Error()
		c.JSON(500, res)
		return
	}
	result, ok := deviceRsp.(*slinkv1.SflHorizontalTurnResponse)
	if !ok {
		logger.Instance().Printf("convert SflHorizontalTurnResponse err")
		res.Result.Code = -1003
		res.Result.Msg = "convert SflHorizontalTurnResponse err"
		c.JSON(500, res)
		return
	}
	logger.Instance().Printf("convert SflHorizontalTurnResponse, status:%v", result.Status)
	var ret = 1
	if result.Status == 0 { //fail
		ret = 2
	}
	res.Data = client.SflHorizontalTurnResponse{
		Status: int32(ret),
	}
	c.JSON(200, res)
}

func SflVerticalTurn(c *gin.Context) {
	res := Response{
		Result: Result{
			Code: 0,
			Msg:  "Success",
		},
	}
	req := &client.SflVerticalTurnRequest{}
	if err := c.ShouldBindJSON(req); err != nil {
		res.Result.Code = -1001
		res.Result.Msg = err.Error()
		c.JSON(400, res)
		return
	}
	var tempTurn uint8

	if req.StartStopTurn == 1 {
		tempTurn = 1
	} else if req.StartStopTurn == 2 {
		tempTurn = 0
	} else {
		res.Result.Code = -1001
		res.Result.Msg = errors.New("StartStopTurn is invalid").Error()
		c.JSON(400, res)
		return
	}
	devicreq := &slinkv1.SflVerticalTurnRequest{
		StartStop: tempTurn,
		Direction: uint8(req.Direction),
		Angle:     uint16(req.Angle),
		Speed:     uint16(req.Speed),
	}

	deviceRsp, err := devicerpc.Call(req.GetSn(), entity.DEV_SFL100, slinkv1.SflVerticalTurn, devicreq)
	if err != nil {
		logger.Instance().Printf("SflVerticalTurnRequest rpc call err %v", err)
		res.Result.Code = -1002
		res.Result.Msg = err.Error()
		c.JSON(500, res)
		return
	}
	result, ok := deviceRsp.(*slinkv1.SflVerticalTurnResponse)
	if !ok {
		logger.Instance().Printf("convert SflVerticalTurnResponse err")
		res.Result.Code = -1003
		res.Result.Msg = "convert SflVerticalTurnResponse err"
		c.JSON(500, res)
		return
	}

	var ret = 1
	if result.Status == 0 { //fail
		ret = 2
	}
	res.Data = client.SflVerticalTurnResponse{
		Status: int32(ret),
	}
	c.JSON(200, res)
}

func SflHitModeSet(c *gin.Context) {
	res := Response{
		Result: Result{
			Code: 0,
			Msg:  "Success",
		},
	}
	req := &client.SflHitModeRequest{}
	if err := c.ShouldBindJSON(req); err != nil {
		res.Result.Code = -1001
		res.Result.Msg = err.Error()
		c.JSON(400, res)
		return
	}

	devicreq := &slinkv1.SflHitModeSetRequest{
		Status: uint8(req.HitMode),
	}

	deviceRsp, err := devicerpc.Call(req.GetSn(), entity.DEV_SFL100, slinkv1.SflSetHitMode, devicreq)
	if err != nil {
		logger.Instance().Printf("SflHitModeSetRequest rpc call err %v", err)
		res.Result.Code = -1002
		res.Result.Msg = err.Error()
		c.JSON(500, res)
		return
	}
	result, ok := deviceRsp.(*slinkv1.SflHitModeSetResponse)
	if !ok {
		logger.Instance().Printf("convert SflHitModeSetResponse err")
		res.Result.Code = -1003
		res.Result.Msg = "convert SflHitModeSetResponse err"
		c.JSON(500, res)
		return
	}

	var ret = 1
	if result.Status == 0 { //fail
		ret = 2
	}
	res.Data = client.SflHitModeResponse{
		Status: int32(ret),
	}
	c.JSON(200, res)
}

func SflTurnHit(c *gin.Context) {
	res := Response{
		Result: Result{
			Code: 0,
			Msg:  "Success",
		},
	}
	req := &client.SflTurnHitRequest{}
	if err := c.ShouldBindJSON(req); err != nil {
		res.Result.Code = -1001
		res.Result.Msg = err.Error()
		c.JSON(400, res)
		return
	}
	var hitTurn uint8

	if req.StartStop == 1 {
		hitTurn = 1
	} else if req.StartStop == 2 {
		hitTurn = 0
	} else {
		res.Result.Code = -1001
		res.Result.Msg = errors.New("StartStop is invalid").Error()
		c.JSON(400, res)
		return
	}
	devicreq := &slinkv1.SflTurnHitRequest{
		StartStop: hitTurn,
	}

	deviceRsp, err := devicerpc.Call(req.GetSn(), entity.DEV_SFL100, slinkv1.SflHitTurn, devicreq)
	if err != nil {
		logger.Instance().Printf("SflTurnHitRequest rpc call err %v", err)
		res.Result.Code = -1002
		res.Result.Msg = err.Error()
		c.JSON(500, res)
		return
	}
	result, ok := deviceRsp.(*slinkv1.SflTurnHitResponse)
	if !ok {
		logger.Instance().Printf("convert SflTurnHitResponse err")
		res.Result.Code = -1003
		res.Result.Msg = "convert SflTurnHitResponse err"
		c.JSON(500, res)
		return
	}

	var ret = 1
	if result.Status == 0 { //fail
		ret = 2
	}
	res.Data = client.SflTurnHitResponse{
		Status: int32(ret),
	}
	c.JSON(200, res)
}

func SflSetAutoHit(c *gin.Context) {
	res := Response{
		Result: Result{
			Code: 0,
			Msg:  "Success",
		},
	}
	req := &client.SflSetAutoHitRequest{}
	if err := c.ShouldBindJSON(req); err != nil {
		res.Result.Code = -1001
		res.Result.Msg = err.Error()
		c.JSON(400, res)
		return
	}
	var autoHit uint8

	//1:自动打击   2:不自动打击
	if req.AutoHit == 1 {
		autoHit = 1
	} else if req.AutoHit == 2 {
		autoHit = 0
	} else {
		res.Result.Code = -1001
		res.Result.Msg = errors.New("autoHit is invalid").Error()
		c.JSON(400, res)
		return
	}
	devicreq := &slinkv1.SflSetAutoHitRequest{
		AutoHit: autoHit,
	}

	deviceRsp, err := devicerpc.Call(req.GetSn(), entity.DEV_SFL100, slinkv1.SflSetAutoHitMode, devicreq)
	if err != nil {
		logger.Instance().Printf("SflTurnHitRequest rpc call err %v", err)
		res.Result.Code = -1002
		res.Result.Msg = err.Error()
		c.JSON(500, res)
		return
	}
	result, ok := deviceRsp.(*slinkv1.SflSetAutoHitResponse)
	if !ok {
		logger.Instance().Printf("convert SflSetAutoHitResponse err")
		res.Result.Code = -1003
		res.Result.Msg = "convert SflSetAutoHitResponse err"
		c.JSON(500, res)
		return
	}

	var ret = 1
	if result.Status == 0 { //fail
		ret = 2
	}
	res.Data = client.SflSetAutoHitResponse{
		Status: int32(ret),
	}
	c.JSON(200, res)
}

func SflGetAutoHit(c *gin.Context) {
	res := Response{
		Result: Result{
			Code: 0,
			Msg:  "Success",
		},
	}
	req := &client.SflGetAutoHitRequest{}
	if err := c.ShouldBindJSON(req); err != nil {
		res.Result.Code = -1001
		res.Result.Msg = err.Error()
		c.JSON(400, res)
		return
	}
	devicreq := &slinkv1.SflGetAutoHitRequest{}

	deviceRsp, err := devicerpc.Call(req.GetSn(), entity.DEV_SFL100, slinkv1.SflGetAutoHitMode, devicreq)
	if err != nil {
		logger.Instance().Printf("SflGetAutoHitRequest rpc call err %v", err)
		res.Result.Code = -1002
		res.Result.Msg = err.Error()
		c.JSON(500, res)
		return
	}
	result, ok := deviceRsp.(*slinkv1.SflGetAutoHitResponse)
	if !ok {
		logger.Instance().Printf("convert SflGetAutoHitResponse err")
		res.Result.Code = -1003
		res.Result.Msg = "convert SflGetAutoHitResponse err"
		c.JSON(500, res)
		return
	}
	//1:自动打击   2:不自动打击
	var ret = 1
	if result.AutoHit == 0 {
		ret = 2
	}
	res.Data = client.SflGetAutoHitResponse{
		AutoHit: int32(ret),
	}
	c.JSON(200, res)
}

func SflSelectUavHit(c *gin.Context) {
	res := Response{
		Result: Result{
			Code: 0,
			Msg:  "Success",
		},
	}
	req := &client.SflSendHitUavRequest{}
	if err := c.ShouldBindJSON(req); err != nil {
		res.Result.Code = -1001
		res.Result.Msg = err.Error()
		c.JSON(400, res)
		return
	}
	var droneName [25]byte
	for i := 0; i < 25 && i < len([]byte(req.DroneName)); i++ {
		droneName[i] = req.DroneName[i]
	}
	var droneSn [32]byte
	for i := 0; i < 32 && i < len([]byte(req.DroneSn)); i++ {
		droneSn[i] = req.DroneSn[i]
	}
	var wifiMac [6]uint8
	if req.WifiMac != nil {
		copy(wifiMac[:], req.WifiMac)
	}
	devicreq := &slinkv1.SflSendHitUavRequest{
		DroneName:    droneName,
		SerialNum:    droneSn,
		DroneHeight:  int16(req.DroneHeight),
		DroneHorizon: int32(req.DroneHorizon),
		DronePitch:   int32(req.DronePitch),
		UFreq:        uint32(req.UFreq),
		WifiMac:      wifiMac,
		UNumber:      uint16(req.UNumber),
		FlagTime:     req.FlagTime,
		Reserve:      [25]uint8{},
	}

	deviceRsp, err := devicerpc.Call(req.GetSn(), entity.DEV_SFL100, slinkv1.SflSendHitUav, devicreq)
	if err != nil {
		logger.Instance().Printf("SflSendHitUavRequest rpc call err %v", err)
		res.Result.Code = -1002
		res.Result.Msg = err.Error()
		c.JSON(500, res)
		return
	}
	result, ok := deviceRsp.(*slinkv1.SflSendHitUavResponse)
	if !ok {
		logger.Instance().Printf("convert SflSendHitUavResponse err")
		res.Result.Code = -1003
		res.Result.Msg = "convert SflSendHitUavResponse err"
		c.JSON(500, res)
		return
	}

	var ret = 1
	if result.Status == 0 { //fail
		ret = 2
	}
	res.Data = client.SflSendHitUavResponse{
		Status: int32(ret),
	}
	c.JSON(200, res)
}

func SflDirectUav(c *gin.Context) {
	res := Response{
		Result: Result{
			Code: 0,
			Msg:  "Success",
		},
	}
	req := &client.SflSendDirectUavRequest{}
	if err := c.ShouldBindJSON(req); err != nil {
		res.Result.Code = -1001
		res.Result.Msg = err.Error()
		c.JSON(400, res)
		return
	}
	var droneName [25]byte
	for i := 0; i < 25 && i < len([]byte(req.DroneName)); i++ {
		droneName[i] = req.DroneName[i]
	}
	var droneSn [32]byte
	for i := 0; i < 32 && i < len([]byte(req.DroneSn)); i++ {
		droneSn[i] = req.DroneSn[i]
	}
	var wifiMac [6]uint8
	if req.WifiMac != nil {
		copy(wifiMac[:], req.WifiMac)
	}
	devicReq := &slinkv1.SflSendDirectUavRequest{
		Mode:         uint8(req.Mode), //1:开始定向  2:结束定向
		DroneName:    droneName,
		SerialNum:    droneSn,
		DroneHeight:  int16(req.DroneHeight),
		DroneHorizon: int32(req.DroneHorizon),
		DronePitch:   int32(req.DronePitch),
		UFreq:        uint32(req.UFreq),
		WifiMac:      wifiMac,
		UNumber:      uint16(req.UNumber),
		FlagTime:     req.FlagTime,
		Reserve:      [25]uint8{},
	}

	deviceRsp, err := devicerpc.Call(req.GetSn(), entity.DEV_SFL100, slinkv1.SflSendDirectUav, devicReq)
	if err != nil {
		logger.Instance().Printf("SflSendDirectUav rpc call err %v", err)
		res.Result.Code = -1002
		res.Result.Msg = err.Error()
		c.JSON(500, res)
		return
	}
	result, ok := deviceRsp.(*slinkv1.SflSendHitUavResponse)
	if !ok {
		logger.Instance().Printf("convert SflSendDirectUav err")
		res.Result.Code = -1003
		res.Result.Msg = "convert SflSendDirectUav err"
		c.JSON(500, res)
		return
	}

	var ret = 1
	if result.Status == 0 { //fail
		ret = 2
	}
	res.Data = client.SflSendHitUavResponse{
		Status: int32(ret),
	}
	c.JSON(200, res)
}
