package common

import (
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
	jsoniter "github.com/json-iterator/go"
	"reflect"
	"testing"
)

func TestTracerBaseNoiseDetectReportMarsh(t *testing.T) {
	var x *slinkv1.TracerBaseNoiseDetectReport = &slinkv1.TracerBaseNoiseDetectReport{
		BaseInfo: slinkv1.TracerSNoiseBaseDataBase{
			Sn:        [25]uint8{'1', '2', '3', '4'},
			FrameNums: 2,
		},
		PowerInfo: []*slinkv1.TracerSNoiseBaseDataAuxiliary{
			&slinkv1.TracerSNoiseBaseDataAuxiliary{MeanPower: 1000, MaxPower: 2000},
		},
	}

	data := x.Format()
	t.Logf("type: %v\n", reflect.TypeOf(data))
	if val, ok := data.(*slinkv1.TracerBaseNoiseDetectReport); ok {
		v, _ := jsoniter.Marshal(WithWebSocketReportType(val.Format(), TracerProNoiseBaseDetect))
		t.Logf("%+v\n", string(v))
	} else {
		t.Logf("not support\n")
	}
	//
	var y *slinkv1.TracerProDetectWifiReport = &slinkv1.TracerProDetectWifiReport{
		Info: slinkv1.TraceProWifiDetect{},
		Description: []*slinkv1.TracerProWifiDetectDesc{
			&slinkv1.TracerProWifiDetectDesc{
				UavNumber: 1,
				WifiMac:   [6]uint8{'a', 'b', 'c'},
				AmpMean:   1000,
			},
			&slinkv1.TracerProWifiDetectDesc{
				UavNumber: 2,
				WifiMac:   [6]uint8{'a', 'b', 'c'},
				AmpMean:   20000,
			},
		},
	}

	datav2 := y.Format()
	if val, ok := datav2.(*slinkv1.TracerProDetectWifiReport); ok {
		v, _ := jsoniter.Marshal(WithWebSocketReportType(val.Format(), TracerProWifiDetect))
		t.Logf("%+v\n", string(v))
	} else {
		t.Logf("not trans ok\n")
	}
}
