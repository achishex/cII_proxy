package common

import (
	"errors"
	"reflect"

	"adasgitlab.autel.com/tools/cuav_proxy/entity/logger"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
	jsoniter "github.com/json-iterator/go"
)

// 数据上报格式返回类型定义
const (
	unknow = 0
	//tracer类数据为100~200
	tracerDetect               = 100
	tracerRemoteDetect         = 101
	tracerFreqDetect           = 102
	tracerFreqDetectExp        = 103
	tracerDroneRemoteDetectExp = 104
	TracerProWifiDetect        = 105
	TracerProNoiseBaseDetect   = 106
	//雷达类数据为 200~300
	radarUploadPosture   = 200
	radarUploadTrackInfo = 201
	radarUploadContro    = 203
)

// WithWebSocketReportType 数据上报返回增加 ReportType
func WithWebSocketReportType(data interface{}, reportType int) interface{} {
	return struct {
		ReportType int
		Data       interface{}
	}{
		ReportType: reportType,
		Data:       data,
	}
}

// Marshal 统一封装websocket返回包格式
func Marshal(data interface{}) ([]byte, error) {
	if val, ok := data.(*slinkv1.TracerDetectResult); ok {
		return jsoniter.Marshal(WithWebSocketReportType(val.Format(), tracerDetect))
	}
	if val, ok := data.(*slinkv1.TracerRemoteDetectResult); ok {
		return jsoniter.Marshal(WithWebSocketReportType(val.Format(), tracerRemoteDetect))
	}
	if val, ok := data.(*slinkv1.TracerFreqDetectResult); ok {
		return jsoniter.Marshal(WithWebSocketReportType(val.Format(), tracerFreqDetect))
	}
	if val, ok := data.(*slinkv1.TracerSFreqDetectExp); ok {
		return jsoniter.Marshal(WithWebSocketReportType(val.Format(), tracerFreqDetectExp))
	}
	if val, ok := data.(*slinkv1.TracerDetectDroneIdRemoteIdResult); ok {
		return jsoniter.Marshal(WithWebSocketReportType(val.Format(), tracerDroneRemoteDetectExp))
	}
	if val, ok := data.(*slinkv1.RadarUploadControlInfo); ok {
		return jsoniter.Marshal(WithWebSocketReportType(val.Format(), radarUploadContro))
	}
	if val, ok := data.(*slinkv1.RadarUploadPostureInfo); ok {
		return jsoniter.Marshal(WithWebSocketReportType(val.Format(), radarUploadPosture))
	}
	if val, ok := data.(*slinkv1.RadarUploadTrackInfoResponse); ok {
		return jsoniter.Marshal(WithWebSocketReportType(val.Format(), radarUploadTrackInfo))
	}
	if val, ok := data.(*slinkv1.TracerProDetectWifiReport); ok {
		return jsoniter.Marshal(WithWebSocketReportType(val.Format(), TracerProWifiDetect))
	}

	if val, ok := data.(*slinkv1.TracerBaseNoiseDetectReport); ok {
		return jsoniter.Marshal(WithWebSocketReportType(val.Format(), TracerProNoiseBaseDetect))
	}

	dataType := reflect.TypeOf(data)
	logger.Instance().Printf("dataType = %+v", dataType)
	return nil, errors.New("unkown data")
}
