package broadcast

import (
	"context"
	"errors"
	"net"

	"adasgitlab.autel.com/tools/cuav_proxy/entity/entity"
	iphelper "adasgitlab.autel.com/tools/cuav_proxy/entity/helper"
	"adasgitlab.autel.com/tools/cuav_proxy/entity/logger"
	"adasgitlab.autel.com/tools/cuav_proxy/rpc/codec"
	"adasgitlab.autel.com/tools/cuav_proxy/rpc/tcpserver"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/generatecode/golang/bizproto"
)

// HandleDiscovery 处理自动发现请求
func HandleDiscovery(ctx context.Context, req interface{}) (interface{}, error) {
	// 获取协议编解码类型
	protoType, ok := ctx.Value(entity.ProtoTypeCxtKey).(uint32)
	if !ok {
		return nil, errors.New("ctx must exist ProtoTypeCxtKey")
	}
	if protoType == codec.SerializationTypeSlink {
		return handleDiscoverySlinkV1(ctx, req)
	}

	if protoType == codec.SerializationTypePB {
		return handleDiscoverySlinkV2(ctx, req)
	}
	return nil, errors.New("not support protoType")
}

func handleDiscoverySlinkV1(ctx context.Context, req interface{}) (interface{}, error) {
	v, ok := req.(*slinkv1.UdpBroadcastConfirmRequest)
	if !ok {
		logger.Instance().Printf("HandleDiscovery convert UdpBroadcastConfirmRequest err")
		return nil, errors.New("HandleDiscovery convert UdpBroadcastConfirmRequest err")
	}
	logger.Instance().Printf("HandleDiscovery UdpBroadcastConfirmRequest %+v", v.Format())
	//根据设备IP选择本地IP，作为回包信息回包
	udpAddr, ok := ctx.Value(entity.UDPAddrCxtKey).(*net.UDPAddr)
	if !ok {
		logger.Instance().Printf("ctx UdpRemoteAddr empty")
		return nil, nil
	}
	matchIP := iphelper.MatchLocalIP(udpAddr.IP.To4().String())
	if matchIP == "" {
		logger.Instance().Printf("MatchLocalIP empty remoteIP %s", udpAddr.IP.To4().String())
		return nil, nil
	}
	matchPort, err := iphelper.GetFreeTCPPort()
	if err != nil {
		logger.Instance().Printf("GetFreeTcpPort empty remoteip %s", udpAddr.IP.To4().String())
		return nil, nil
	}
	svr := tcpserver.TcpServerMgrInstance().GetServer(v.GetSn())
	if svr != nil {
		matchIP = svr.IP
		matchPort = svr.Port
	} else {
		server := tcpserver.NewTcpServer(tcpserver.WithIP(matchIP), tcpserver.WithPort(matchPort), tcpserver.WithSn(v.GetSn()))
		tcpserver.TcpServerMgrInstance().SetServer(v.GetSn(), server)
		go server.Start()
	}
	rsp := &slinkv1.UdpBroadcastConfirmResponse{
		Sn:       v.Sn,
		Addr:     iphelper.IPV4(matchIP),
		Port:     uint16(matchPort),
		ConnType: 1,
	}
	return rsp, nil
}

func handleDiscoverySlinkV2(ctx context.Context, req interface{}) (interface{}, error) {
	v, ok := req.(*bizproto.UdpBroadcastConfirmReq)
	if !ok {
		logger.Instance().Printf("HandleDiscovery convert UdpBroadcastConfirmRequest err")
		return nil, errors.New("HandleDiscovery convert UdpBroadcastConfirmRequest err")
	}
	//根据设备IP选择本地IP，作为回包信息回包
	udpAddr, ok := ctx.Value(entity.UDPAddrCxtKey).(*net.UDPAddr)
	if !ok {
		logger.Instance().Printf("ctx UdpRemoteAddr empty")
		return nil, nil
	}
	matchIP := iphelper.MatchLocalIP(udpAddr.IP.To4().String())
	if matchIP == "" {
		logger.Instance().Printf("MatchLocalIP empty remoteIP %s", udpAddr.IP.To4().String())
		return nil, nil
	}
	matchPort, err := iphelper.GetFreeTCPPort()
	if err != nil {
		logger.Instance().Printf("GetFreeTcpPort empty remoteip %s", udpAddr.IP.To4().String())
		return nil, nil
	}
	svr := tcpserver.TcpServerMgrInstance().GetServer(v.GetSn())
	if svr != nil {
		matchIP = svr.IP
		matchPort = svr.Port
	} else {
		server := tcpserver.NewTcpServer(tcpserver.WithIP(matchIP), tcpserver.WithPort(matchPort), tcpserver.WithSn(v.GetSn()))
		tcpserver.TcpServerMgrInstance().SetServer(v.GetSn(), server)
		go server.Start()
	}
	rsp := &bizproto.UdpBroadcastConfirmRsp{
		Sn:       v.Sn,
		Addr:     matchIP,
		Port:     uint32(matchPort),
		ConnType: 1,
	}
	return rsp, nil
}
