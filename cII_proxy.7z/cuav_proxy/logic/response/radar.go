package response

import (
	"context"
	"errors"

	"adasgitlab.autel.com/tools/cuav_proxy/entity/entity"
	"adasgitlab.autel.com/tools/cuav_proxy/entity/logger"
	"adasgitlab.autel.com/tools/cuav_proxy/rpc/cmdhandler"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
)

// SetSystemStatusResponse 设置雷达系统状态
func SetSystemStatusResponse(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*slinkv1.RadarSetSystemStatusResponse)
	if !ok {
		logger.Instance().Printf("covert RadarSetSystemStatusResponse err")
		return nil, errors.New("covert RadarSetSystemStatusResponse err")
	}
	return rsp, nil
}

// GetSystemInfoResponse 查询雷达系统信息
func GetSystemInfoResponse(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*slinkv1.RadarGetSystemInfoResponse)
	if !ok {
		logger.Instance().Printf("covert RadarGetSystemInfoResponse err")
		return nil, errors.New("covert RadarGetSystemInfoResponse err")
	}
	logger.Instance().Printf("RadarGetSystemInfoResponse %+v", rsp)
	return rsp, nil
}

func init() {
	cmdhandler.Instance().RegisterHandler(entity.DEV_RADAR, slinkv1.RadarIdSetSystemStatus, SetSystemStatusResponse)
	cmdhandler.Instance().RegisterHandler(entity.DEV_RADAR, slinkv1.RadarIdGetSystemInfo, GetSystemInfoResponse)
}
