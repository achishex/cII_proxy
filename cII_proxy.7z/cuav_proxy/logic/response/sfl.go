package response

import (
	"adasgitlab.autel.com/tools/cuav_proxy/entity/entity"
	"adasgitlab.autel.com/tools/cuav_proxy/entity/logger"
	"adasgitlab.autel.com/tools/cuav_proxy/rpc/cmdhandler"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
	"context"
	"errors"
)

func SflHitInfo(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	logger.Instance().Printf("receive SflHitInfoResponse")
	rsp, ok := data.(*slinkv1.SflSetHitInfoResponse)
	if !ok {
		logger.Instance().Printf("covert SflHitInfoResponse err")
		return nil, errors.New("covert SflHitInfoResponse err")
	}
	return rsp, nil
}

// SflHitAngle SFL设置打击点信息
func SflHitAngle(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	logger.Instance().Printf("receive SflSetHitAngleResponse")
	rsp, ok := data.(*slinkv1.SflSetHitAngleResponse)
	if !ok {
		logger.Instance().Printf("covert SflSetHitAngleResponse err")
		return nil, errors.New("covert SflSetHitAngleResponse err")
	}
	return rsp, nil
}

// SflHorizontalTurn SFL水平转动
func SflHorizontalTurn(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	logger.Instance().Printf("receive SflHitAngleResponse")
	rsp, ok := data.(*slinkv1.SflHorizontalTurnResponse)
	if !ok {
		logger.Instance().Printf("covert SflHorizontalTurnResponse err")
		return nil, errors.New("covert SflHorizontalTurnResponse err")
	}
	return rsp, nil
}

// SflVerticalTurn SFL垂直转动
func SflVerticalTurn(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*slinkv1.SflVerticalTurnResponse)
	if !ok {
		logger.Instance().Printf("covert SflVerticalTurnResponse err")
		return nil, errors.New("covert SflVerticalTurnResponse err")
	}
	return rsp, nil
}

// SflSetHitMode SFL设置打击模式
func SflSetHitMode(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*slinkv1.SflHitModeSetResponse)
	if !ok {
		logger.Instance().Printf("covert SflHitModeSetResponse err")
		return nil, errors.New("covert SflHitModeSetResponse err")
	}
	return rsp, nil
}

// SflTurnHit SFL打击
func SflTurnHit(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*slinkv1.SflTurnHitResponse)
	if !ok {
		logger.Instance().Printf("covert SflTurnHitResponse err")
		return nil, errors.New("covert SflTurnHitResponse err")
	}
	return rsp, nil
}

// SflSetAutoHit SFL设置自动打击
func SflSetAutoHit(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*slinkv1.SflSetAutoHitResponse)
	if !ok {
		logger.Instance().Printf("covert SflSetAutoHitResponse err")
		return nil, errors.New("covert SflSetAutoHitResponse err")
	}
	return rsp, nil
}

// SflGetAutoHit SFL获取自动打击
func SflGetAutoHit(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*slinkv1.SflGetAutoHitResponse)
	if !ok {
		logger.Instance().Printf("covert SflGetAutoHitResponse err")
		return nil, errors.New("covert SflGetAutoHitResponse err")
	}
	return rsp, nil
}

// SflSelectHitUav SFL选择打击目标
func SflSelectHitUav(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*slinkv1.SflSendHitUavResponse)
	if !ok {
		logger.Instance().Printf("covert SflSendHitUavResponse err")
		return nil, errors.New("covert SflSendHitUavResponse err")
	}
	return rsp, nil
}

// SflDirectUav SFL开始定向
func SflDirectUav(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*slinkv1.SflSendDirectUavResponse)
	if !ok {
		logger.Instance().Printf("covert SflSendDirectUavResponse err")
		return nil, errors.New("covert SflSendDirectUavResponse err")
	}
	return rsp, nil
}

func init() {
	cmdhandler.Instance().RegisterHandler(entity.DEV_SFL100, slinkv1.SflSetPith, SflHitInfo)
	cmdhandler.Instance().RegisterHandler(entity.DEV_SFL100, slinkv1.SflSetAngle, SflHitAngle)
	cmdhandler.Instance().RegisterHandler(entity.DEV_SFL100, slinkv1.SflHorizontalTurn, SflHorizontalTurn)
	cmdhandler.Instance().RegisterHandler(entity.DEV_SFL100, slinkv1.SflVerticalTurn, SflVerticalTurn)
	cmdhandler.Instance().RegisterHandler(entity.DEV_SFL100, slinkv1.SflSetHitMode, SflSetHitMode)
	cmdhandler.Instance().RegisterHandler(entity.DEV_SFL100, slinkv1.SflHitTurn, SflTurnHit)
	cmdhandler.Instance().RegisterHandler(entity.DEV_SFL100, slinkv1.SflSetAutoHitMode, SflSetAutoHit)
	cmdhandler.Instance().RegisterHandler(entity.DEV_SFL100, slinkv1.SflGetAutoHitMode, SflGetAutoHit)
	cmdhandler.Instance().RegisterHandler(entity.DEV_SFL100, slinkv1.SflSendHitUav, SflSelectHitUav)
	cmdhandler.Instance().RegisterHandler(entity.DEV_SFL100, slinkv1.SflSendDirectUav, SflDirectUav)
}
