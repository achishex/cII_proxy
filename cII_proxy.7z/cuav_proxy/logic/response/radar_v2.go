package response

import (
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/generatecode/golang/bizproto"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/msgid"
	"context"
	"errors"
	"reflect"

	"adasgitlab.autel.com/tools/cuav_proxy/entity/entity"
	"adasgitlab.autel.com/tools/cuav_proxy/entity/logger"
	"adasgitlab.autel.com/tools/cuav_proxy/rpc/cmdhandler"
)

// RadarIdV2SetAttitudeLLAResponse 设置雷达经纬高
func RadarIdV2SetAttitudeLLAResponse(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*bizproto.RadarSetAttitudeLLARsp)
	if !ok {
		dataType := reflect.TypeOf(data)
		logger.Instance().Printf("dataType = %+v", dataType)
		logger.Instance().Printf("covert RadarIdV2SetAttitudeLLAResponse err")
		return nil, errors.New("covert RadarIdV2SetAttitudeLLAResponse err")
	}
	return rsp, nil
}

// RadarIdV2SetSettingResponse 设置雷达信息
func RadarIdV2SetSettingResponse(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*bizproto.RadarSetRsp)
	if !ok {
		logger.Instance().Printf("covert RadarIdV2SetSettingResponse err")
		return nil, errors.New("covert RadarIdV2SetSettingResponse err")
	}
	logger.Instance().Printf("RadarIdV2SetSettingResponse %+v", rsp)
	return rsp, nil
}

// RadarIdV2GetConfigResponse 设置雷达信息
func RadarIdV2GetConfigResponse(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*bizproto.RadarReadConfigRsp)
	if !ok {
		logger.Instance().Printf("covert RadarReadConfigRsp err")
		return nil, errors.New("covert RadarReadConfigRsp err")
	}
	logger.Instance().Printf("RadarReadConfigRsp %+v", rsp)
	return rsp, nil
}

// RadarIdV2SetConfigResponse 设置雷达信息
func RadarIdV2SetConfigResponse(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*bizproto.RadarConfigRsp)
	if !ok {
		logger.Instance().Printf("covert RadarIdV2SetConfigResponse err")
		return nil, errors.New("covert RadarIdV2SetConfigResponse err")
	}
	logger.Instance().Printf("RadarIdV2SetConfigResponse %+v", rsp)
	return rsp, nil
}

// RadarIdV2SetBeamSchedulingResponse 设置雷达信息
func RadarIdV2SetBeamSchedulingResponse(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*bizproto.RadarSetBeamSchedulingRsp)
	if !ok {
		logger.Instance().Printf("covert RadarIdV2SetBeamSchedulingResponse err")
		return nil, errors.New("covert RadarIdV2SetBeamSchedulingResponse err")
	}
	logger.Instance().Printf("RadarIdV2SetBeamSchedulingResponse %+v", rsp)
	return rsp, nil
}

func init() {
	cmdhandler.Instance().RegisterHandler(entity.DEV_RADAR, msgid.RadarIdV2SetAttitudeLLA, RadarIdV2SetAttitudeLLAResponse)
	cmdhandler.Instance().RegisterHandler(entity.DEV_RADAR, msgid.RadarIdV2SetSetting, RadarIdV2SetSettingResponse)
	cmdhandler.Instance().RegisterHandler(entity.DEV_RADAR, msgid.RadarIdV2GetConfig, RadarIdV2GetConfigResponse)
	cmdhandler.Instance().RegisterHandler(entity.DEV_RADAR, msgid.RadarIdV2SetConfig, RadarIdV2SetConfigResponse)
	cmdhandler.Instance().RegisterHandler(entity.DEV_RADAR, msgid.RadarIdV2SetBeamScheduling, RadarIdV2SetBeamSchedulingResponse)

}
