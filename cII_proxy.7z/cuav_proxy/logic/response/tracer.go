package response

import (
	"context"
	"errors"
	"reflect"

	"adasgitlab.autel.com/tools/cuav_proxy/entity/entity"
	"adasgitlab.autel.com/tools/cuav_proxy/entity/logger"
	"adasgitlab.autel.com/tools/cuav_proxy/rpc/cmdhandler"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
)

// SetTracerWorkMode 设置Tracer工作模式
func SetTracerWorkMode(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*slinkv1.TracerSetOrientationModeResponse)
	if !ok {
		logger.Instance().Printf("covert TracerSetOrientationModeResponse err")
		return nil, errors.New("covert TracerSetOrientationModeResponse err")
	}
	return rsp, nil
}

// TracerGetWorkMode 获取Tracer工作模式
func TracerGetWorkMode(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*slinkv1.TracerGetWorkModeResponse)
	if !ok {
		logger.Instance().Printf("covert TracerGetWorkModeResponse err")
		return nil, errors.New("covert TracerGetWorkModeResponse err")
	}
	return rsp, nil
}

// TracerSetAlarmLevelMode tracer 告警
func TracerSetAlarmLevelMode(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*slinkv1.TracerAlarmModeResult)
	if !ok {
		logger.Instance().Printf("covert TracerAlarmModeResult err")
		return nil, errors.New("covert TracerAlarmModeResult err")
	}
	return rsp, nil
}

// TracerSetWhiteListMode tracer 白名单
func TracerSetWhiteListMode(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*slinkv1.TracerWhiteListResult)
	if !ok {
		logger.Instance().Printf("covert TracerWhiteListResult err")
		return nil, errors.New("covert TracerWhiteListResult err")
	}
	return rsp, nil
}

// TracerSetHideModeF tracer 隐蔽模式
func TracerSetHideModeF(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	logger.Instance().Printf(reflect.ValueOf(data).Elem().Kind().String())
	dataType := reflect.TypeOf(data)
	logger.Instance().Printf("%+v", dataType)
	rsp, ok := data.(*slinkv1.TracerSetHideModeResult)
	if !ok {
		logger.Instance().Printf("covert TracerSetHideModeResponse err")
		return nil, errors.New("covert TracerSetHideModeResponse err")
	}
	return rsp, nil
}

func TracerSetVideoParam(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	logger.Instance().Printf(reflect.ValueOf(data).Elem().Kind().String())
	dataType := reflect.TypeOf(data)
	logger.Instance().Printf("%+v", dataType)
	rsp, ok := data.(*slinkv1.TracerSetVideParamResponse)
	if !ok {
		logger.Instance().Printf("covert TracerSetVideParamResponse err")
		return nil, errors.New("covert TracerSetVideParamResponse err")
	}
	return rsp, nil
}

func TracerSetNoiseFloor(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	logger.Instance().Printf(reflect.ValueOf(data).Elem().Kind().String())
	dataType := reflect.TypeOf(data)
	logger.Instance().Printf("%+v", dataType)
	rsp, ok := data.(*slinkv1.TracerSetBaseNoiseResponse)
	if !ok {
		logger.Instance().Printf("covert TracerSetBaseNoiseResponse err")
		return nil, errors.New("covert TracerSetBaseNoiseResponse err")
	}
	return rsp, nil
}

func TracerProSetOrient(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	logger.Instance().Printf(reflect.ValueOf(data).Elem().Kind().String())
	dataType := reflect.TypeOf(data)
	logger.Instance().Printf("%+v", dataType)
	rsp, ok := data.(*slinkv1.TracerProSetOrientResponse)
	if !ok {
		logger.Instance().Printf("covert TracerProSetOrientResponse err")
		return nil, errors.New("covert TracerProSetOrientResponse err")
	}
	return rsp, nil
}
func TracerCliSend(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	logger.Instance().Printf(reflect.ValueOf(data).Elem().Kind().String())
	dataType := reflect.TypeOf(data)
	logger.Instance().Printf("%+v", dataType)
	rsp, ok := data.(*slinkv1.TracerCliResponse)
	if !ok {
		logger.Instance().Printf("covert TracerCliResponse err")
		return nil, errors.New("covert TracerCliResponse err")
	}
	return rsp, nil
}

func init() {
	cmdhandler.Instance().RegisterHandler(entity.DEV_V2DRONEID, slinkv1.TracerSetOrientationMode, SetTracerWorkMode)
	cmdhandler.Instance().RegisterHandler(entity.DEV_V2DRONEID, slinkv1.TracerGetWorkMode, TracerGetWorkMode)
	cmdhandler.Instance().RegisterHandler(entity.DEV_V2DRONEID, slinkv1.TracerSetAlarmLevel, TracerSetAlarmLevelMode)
	cmdhandler.Instance().RegisterHandler(entity.DEV_V2DRONEID, slinkv1.TracerSetWhiteList, TracerSetWhiteListMode)
	cmdhandler.Instance().RegisterHandler(entity.DEV_V2DRONEID, slinkv1.TracerSetHideMode, TracerSetHideModeF)

	cmdhandler.Instance().RegisterHandler(entity.DEV_V2DRONEID, slinkv1.TracerSetVideoParam, TracerSetVideoParam)
	cmdhandler.Instance().RegisterHandler(entity.DEV_V2DRONEID, slinkv1.TracerSetNoiseFloor, TracerSetNoiseFloor)
	cmdhandler.Instance().RegisterHandler(entity.DEV_V2DRONEID, slinkv1.TracerProSetOrient, TracerProSetOrient)
	cmdhandler.Instance().RegisterHandler(entity.DEV_V2DRONEID, slinkv1.TracerCliSend, TracerCliSend)
}
