package report

import (
	"context"
	"errors"

	"adasgitlab.autel.com/tools/cuav_proxy/entity/entity"
	"adasgitlab.autel.com/tools/cuav_proxy/entity/logger"
	"adasgitlab.autel.com/tools/cuav_proxy/rpc/cmdhandler"
	"adasgitlab.autel.com/tools/cuav_proxy/rpc/webclient"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"

	jsoniter "github.com/json-iterator/go"
)

// RadarContolrInfo 上报雷达控制信息
func RadarContolrInfo(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*slinkv1.RadarUploadControlInfo)
	if !ok {
		logger.Instance().Printf("covert RadarUploadControlInfo err")
		return nil, errors.New("covert RadarUploadControlInfo err")
	}
	buff, err := jsoniter.Marshal(rsp)
	if err != nil {
		logger.Instance().Printf("RadarContolrInfo Marshal json err %v", err)
		return nil, errors.New("RadarContolrInfo encode err")
	}
	if err = webclient.ClientMgrInstance().SendData(buff); err != nil {
		logger.Instance().Printf("RadarContolrInfo SendData err %v", err)
	}
	return nil, nil
}

// PostureInfo 上报雷达姿态信息
func PostureInfo(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*slinkv1.RadarUploadPostureInfo)
	if !ok {
		logger.Instance().Printf("covert RadarUploadPostureInfo err")
		return nil, errors.New("covert RadarUploadPostureInfo err")
	}
	buff, err := jsoniter.Marshal(rsp)
	if err != nil {
		logger.Instance().Printf("PostureInfo Marshal json err %v", err)
		return nil, errors.New("PostureInfo encode err")
	}
	if err = webclient.ClientMgrInstance().SendData(buff); err != nil {
		logger.Instance().Printf("PostureInfo SendData err %v", err)
	}
	return nil, nil
}

// TrackInfo 上报雷达轨迹信息
func TrackInfo(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*slinkv1.RadarUploadTrackInfoResponse)
	if !ok {
		logger.Instance().Printf("covert RadarUploadTrackInfoResponse err")
		return nil, errors.New("covert RadarUploadTrackInfoResponse err")
	}
	buff, err := jsoniter.Marshal(rsp)
	if err != nil {
		logger.Instance().Printf("TrackInfo Marshal json err %v", err)
		return nil, errors.New("TrackInfo encode err")
	}
	if err = webclient.ClientMgrInstance().SendData(buff); err != nil {
		logger.Instance().Printf("TrackInfo SendData err %v", err)
	}
	return nil, nil
}

func init() {
	cmdhandler.Instance().RegisterHandler(entity.DEV_RADAR, slinkv1.RadarIdUploadTrackInfo, TrackInfo)
	cmdhandler.Instance().RegisterHandler(entity.DEV_RADAR, slinkv1.RadarIdUploadControlInfo, RadarContolrInfo)
	cmdhandler.Instance().RegisterHandler(entity.DEV_RADAR, slinkv1.RadarIdUploadPosture, PostureInfo)
}
