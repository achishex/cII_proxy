package report

import (
	"adasgitlab.autel.com/tools/cuav_proxy/entity/entity"
	"adasgitlab.autel.com/tools/cuav_proxy/entity/logger"
	jsoniterx "adasgitlab.autel.com/tools/cuav_proxy/logic/common"
	"adasgitlab.autel.com/tools/cuav_proxy/rpc/cmdhandler"
	"adasgitlab.autel.com/tools/cuav_proxy/rpc/webclient"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
	"context"
	"errors"
)

// TracerDetect 上报Tracer探测结果
func TracerDetect(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*slinkv1.TracerDetectResult)
	if !ok {
		logger.Instance().Printf("covert TracerDetectResult err")
		return nil, errors.New("covert TracerDetectResult err")
	}

	buff, err := jsoniterx.Marshal(rsp)
	if err != nil {
		logger.Instance().Printf("TracerDetectResult Marshal json err %v", err)
		return nil, errors.New("TracerDetect encode err")
	}
	if err = webclient.ClientMgrInstance().SendData(buff); err != nil {
		logger.Instance().Printf("TracerDetect SendData err %v", err)
	}
	return nil, nil
}

// TracerIDGetRemoteIDDetectMode 获取Tracer工作模式
func TracerIDGetRemoteIDDetectMode(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*slinkv1.TracerRemoteDetectResult)
	if !ok {
		logger.Instance().Printf("covert TracerRemoteDetectResult err")
		return nil, errors.New("covert TracerRemoteDetectResult err")
	}
	// rsp.Format()
	buff, err := jsoniterx.Marshal(rsp)
	if err != nil {
		logger.Instance().Printf("TracerRemoteDetectResult Marshal json err %v", err)
		return nil, errors.New("TracerRemoteDetectResult encode err")
	}
	if err = webclient.ClientMgrInstance().SendData(buff); err != nil {
		logger.Instance().Printf("TracerDetect SendData err %v", err)
	}
	return nil, nil
}

// TracerIDGetFreqDetectMode 获取Tracer 频谱
func TracerIDGetFreqDetectMode(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*slinkv1.TracerFreqDetectResult)
	if !ok {
		logger.Instance().Printf("covert TracerFreqDetectResult err")
		return nil, errors.New("covert TracerFreqDetectResult err")
	}
	// rsp.Format()
	buff, err := jsoniterx.Marshal(rsp)
	if err != nil {
		logger.Instance().Printf("TracerFreqDetectResult Marshal json err %v", err)
		return nil, errors.New("TracerFreqDetectResult encode err")
	}
	if err = webclient.ClientMgrInstance().SendData(buff); err != nil {
		logger.Instance().Printf("TracerDetect SendData err %v", err)
	}
	return nil, nil
}

// TracerIDGetFreqDetectModeExp 获取Tracer 频谱
func TracerIDGetFreqDetectModeExp(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*slinkv1.TracerSFreqDetectExp)
	if !ok {
		logger.Instance().Printf("covert TracerSFreqDetectExp err")
		return nil, errors.New("covert TracerSFreqDetectExp err")
	}
	// rsp.Format()
	buff, err := jsoniterx.Marshal(rsp)
	if err != nil {
		logger.Instance().Printf("TracerSFreqDetectExp Marshal json err %v", err)
		return nil, errors.New("TracerSFreqDetectExp encode err")
	}
	if err = webclient.ClientMgrInstance().SendData(buff); err != nil {
		logger.Instance().Printf("TracerIDGetFreqDetectModeExp SendData err %v", err)
	}
	return nil, nil
}

// TracerProWifiDetectReport tracerPro 侦测结果上报
func TracerProWifiDetectReport(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*slinkv1.TracerProDetectWifiReport)
	if !ok {
		logger.Instance().Printf("covert TracerProDetectWifiReport err")
		return nil, errors.New("covert TracerProDetectWifiReport err")
	}
	// rsp.Format()
	buff, err := jsoniterx.Marshal(rsp)
	if err != nil {
		logger.Instance().Printf("TracerProDetectWifiReport Marshal json err %v", err)
		return nil, errors.New("TracerProDetectWifiReport encode err")
	}
	if err = webclient.ClientMgrInstance().SendData(buff); err != nil {
		logger.Instance().Printf("TracerProDetectWifiReport SendData err %v", err)
	}
	return nil, nil
}

// TracerDetectFreqBaseNoiseReport 噪声侦测上报
func TracerDetectFreqBaseNoiseReport(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*slinkv1.TracerBaseNoiseDetectReport)
	if !ok {
		logger.Instance().Printf("covert TracerBaseNoiseDetectReport err")
		return nil, errors.New("covert TracerBaseNoiseDetectReport err")
	}
	// rsp.Format()
	buff, err := jsoniterx.Marshal(rsp)
	if err != nil {
		logger.Instance().Printf("TracerBaseNoiseDetectReport Marshal json err %v", err)
		return nil, errors.New("TracerBaseNoiseDetectReport encode err")
	}
	if err = webclient.ClientMgrInstance().SendData(buff); err != nil {
		logger.Instance().Printf("TracerBaseNoiseDetectReport SendData err %v", err)
	}
	return nil, nil
}
func init() {
	cmdhandler.Instance().RegisterHandler(entity.DEV_V2DRONEID, slinkv1.TracerIdGetDetectRes, TracerDetect)
	cmdhandler.Instance().RegisterHandler(entity.DEV_V2DRONEID, slinkv1.TracerIdGetRemoteIdDetectRes, TracerIDGetRemoteIDDetectMode)
	cmdhandler.Instance().RegisterHandler(entity.DEV_V2DRONEID, slinkv1.TracerIdGetFreqDetectRes, TracerIDGetFreqDetectMode)
	cmdhandler.Instance().RegisterHandler(entity.DEV_V2DRONEID, slinkv1.TracerIdGetFreqDetectResExp, TracerIDGetFreqDetectModeExp)
	cmdhandler.Instance().RegisterHandler(entity.DEV_V2DRONEID, slinkv1.TracerProWifiDetectReport, TracerProWifiDetectReport)
	cmdhandler.Instance().RegisterHandler(entity.DEV_V2DRONEID, slinkv1.TracerSBaseNoiseReport, TracerDetectFreqBaseNoiseReport)
}
