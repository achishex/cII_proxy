package report

import (
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/generatecode/golang/bizproto"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/msgid"
	"context"
	"errors"

	"adasgitlab.autel.com/tools/cuav_proxy/entity/entity"
	"adasgitlab.autel.com/tools/cuav_proxy/entity/logger"
	"adasgitlab.autel.com/tools/cuav_proxy/rpc/cmdhandler"
	"adasgitlab.autel.com/tools/cuav_proxy/rpc/webclient"
	jsoniter "github.com/json-iterator/go"
)

type WsResult struct {
	Typ  string      `json:"type"`
	Data interface{} `json:"data"`
}

// DetectInfo 上报雷达轨迹信息
func DetectInfoV2(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*bizproto.RadarDetect)
	if !ok {
		logger.Instance().Printf("covert radar SlinkDetect err")
		return nil, errors.New("covert radar SlinkDetect err")
	}
	rst := &WsResult{"DetectInfo", rsp}
	buff, err := jsoniter.Marshal(rst)
	if err != nil {
		logger.Instance().Printf("SlinkDetect Marshal json err %v", err)
		return nil, errors.New("SlinkDetect encode err")
	}
	if err = webclient.ClientMgrInstance().SendData(buff); err != nil {
		logger.Instance().Printf("SlinkDetect SendData err %v", err)
	}
	return nil, nil
}

// TrackInfo 上报雷达轨迹信息
func TrackInfoV2(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*bizproto.RadarTrack)
	if !ok {
		logger.Instance().Printf("covert radar SlinkTrack err")
		return nil, errors.New("covert radar SlinkTrack err")
	}
	rst := &WsResult{"TrackInfo", rsp}
	buff, err := jsoniter.Marshal(rst)
	if err != nil {
		logger.Instance().Printf("SlinkTrack Marshal json err %v", err)
		return nil, errors.New("SlinkTrack encode err")
	}
	if err = webclient.ClientMgrInstance().SendData(buff); err != nil {
		logger.Instance().Printf("SlinkTrack SendData err %v", err)
	}
	return nil, nil
}

// DotCoheInfo 上报雷达轨迹信息
func DotCoheInfoV2(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*bizproto.RadarDotCohe)
	if !ok {
		logger.Instance().Printf("covert radar SlinkDotCohe err")
		return nil, errors.New("covert radar SlinkDotCohe err")
	}
	rst := &WsResult{"DotCoheInfo", rsp}
	buff, err := jsoniter.Marshal(rst)
	if err != nil {
		logger.Instance().Printf("SlinkDotCohe Marshal json err %v", err)
		return nil, errors.New("SlinkDotCohe encode err")
	}
	if err = webclient.ClientMgrInstance().SendData(buff); err != nil {
		logger.Instance().Printf("SlinkDotCohe SendData err %v", err)
	}
	return nil, nil
}

// StateInfo 上报雷达轨迹信息
func StateInfoV2(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*bizproto.RadarState)
	if !ok {
		logger.Instance().Printf("covert radar StateInfo err")
		return nil, errors.New("covert radar StateInfo err")
	}
	rst := &WsResult{"StateInfo", rsp}
	buff, err := jsoniter.Marshal(rst)
	if err != nil {
		logger.Instance().Printf("StateInfo Marshal json err %v", err)
		return nil, errors.New("StateInfo encode err")
	}
	if err = webclient.ClientMgrInstance().SendData(buff); err != nil {
		logger.Instance().Printf("StateInfo SendData err %v", err)
	}
	return nil, nil
}

// BeamInfo 上报雷达轨迹信息
func BeamInfoV2(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*bizproto.RadarBeamScheduling)
	if !ok {
		logger.Instance().Printf("covert radar BeamInfo err")
		return nil, errors.New("covert radar BeamInfo err")
	}
	rst := &WsResult{"BeamInfo", rsp}
	buff, err := jsoniter.Marshal(rst)
	if err != nil {
		logger.Instance().Printf("BeamInfo Marshal json err %v", err)
		return nil, errors.New("BeamInfo encode err")
	}
	if err = webclient.ClientMgrInstance().SendData(buff); err != nil {
		logger.Instance().Printf("BeamInfo SendData err %v", err)
	}
	return nil, nil
}

func init() {

	cmdhandler.Instance().RegisterHandler(entity.DEV_RADAR, msgid.RadarIdV2Detect, DetectInfoV2)
	cmdhandler.Instance().RegisterHandler(entity.DEV_RADAR, msgid.RadarIdV2Track, TrackInfoV2)
	cmdhandler.Instance().RegisterHandler(entity.DEV_RADAR, msgid.RadarIdV2DotCohe, DotCoheInfoV2)
	cmdhandler.Instance().RegisterHandler(entity.DEV_RADAR, msgid.RadarIdV2State, StateInfoV2)
	cmdhandler.Instance().RegisterHandler(entity.DEV_RADAR, msgid.RadarIdV2BeamScheduling, BeamInfoV2)

}
