package report

import (
	"adasgitlab.autel.com/tools/cuav_proxy/entity/entity"
	"adasgitlab.autel.com/tools/cuav_proxy/entity/logger"
	"adasgitlab.autel.com/tools/cuav_proxy/rpc/cmdhandler"
	"adasgitlab.autel.com/tools/cuav_proxy/rpc/webclient"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
	"context"
	"errors"
	jsoniter "github.com/json-iterator/go"
)

// SflDetectUav 上报Slf探测无人机结果
func SflDetectUav(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	logger.Instance().Printf("------------------->receive DetectUav")
	rsp, ok := data.(*slinkv1.SflDetect)
	if !ok {
		logger.Instance().Printf("covert SflDetect err")
		return nil, errors.New("covert SflDetect err")
	}
	buff, err := jsoniter.Marshal(rsp)
	if err != nil {
		logger.Instance().Printf("SflDetectUav Marshal json err %v", err)
		return nil, errors.New("SflDetectUav encode err")
	}
	if err = webclient.ClientMgrInstance().SendData(buff); err != nil {
		logger.Instance().Printf("SflDetectUav SendData err %v", err)
	}
	return nil, nil
}

// SflHeart 上报Slf心跳
func SflHeart(ctx context.Context, sn string, data interface{}) (interface{}, error) {
	rsp, ok := data.(*slinkv1.SflHeart)
	if !ok {
		logger.Instance().Printf("covert SflHeart err")
		return nil, errors.New("covert SflHeart err")
	}

	buff, err := jsoniter.Marshal(rsp)
	if err != nil {
		logger.Instance().Printf("SflHeart Marshal json err %v", err)
		return nil, errors.New("SflHeart encode err")
	}
	if err = webclient.ClientMgrInstance().SendData(buff); err != nil {
		logger.Instance().Printf("SflHeart SendData err %v", err)
	}
	return nil, nil
}

func init() {
	cmdhandler.Instance().RegisterHandler(entity.DEV_SFL100, slinkv1.SflDetectMsg, SflDetectUav)
	cmdhandler.Instance().RegisterHandler(entity.DEV_SFL100, slinkv1.SflHeartMsg, SflHeart)
}
