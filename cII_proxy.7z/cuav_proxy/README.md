# cuav_proxy

C2的代理层服务，封装雷达和tracer设备侧的接口