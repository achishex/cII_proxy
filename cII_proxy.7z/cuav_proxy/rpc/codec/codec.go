package codec

import (
	"errors"
	"reflect"
	"sync"

	"adasgitlab.autel.com/tools/cuav_proxy/entity/entity"
	"adasgitlab.autel.com/tools/cuav_proxy/entity/logger"
)

// Codec 解码管理器
type Codec struct {
	mu       sync.Mutex
	cmdCoder map[entity.DeviceType]map[uint16]interface{}
}

var (
	codecInstance *Codec
	codecOnce     sync.Once
)

// Instance 单例
func Instance() *Codec {
	codecOnce.Do(func() {
		codecInstance = &Codec{
			cmdCoder: make(map[entity.DeviceType]map[uint16]interface{}),
		}
	})
	return codecInstance
}

// Register 注册命令字请求响应编解码
func (c *Codec) Register(deviceType entity.DeviceType, cmd uint16, rsp interface{}) {
	c.mu.Lock()
	defer c.mu.Unlock()
	logger.Instance().Printf("Codec Register deviceType %d cmd %d Decoder %s", deviceType, cmd, reflect.TypeOf(rsp).String())
	if c.cmdCoder[deviceType] == nil {
		c.cmdCoder[deviceType] = make(map[uint16]interface{})
	}
	c.cmdCoder[deviceType][cmd] = rsp
}

// Get 获取设备下命令字请求响应编解码
func (c *Codec) Get(deviceType entity.DeviceType, cmd uint16) (interface{}, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if _, ok := c.cmdCoder[deviceType]; !ok {
		logger.Instance().Printf("deviceType %d not register codec", deviceType)
		return nil, errors.New("deviceType not register codec")
	}
	v, ok := c.cmdCoder[deviceType][cmd]
	if !ok {
		logger.Instance().Printf("deviceType %d cmd %X not register codec", deviceType, cmd)
		return nil, errors.New("cmd not register codec")
	}
	rspCoder := reflect.TypeOf(v).Elem()
	if rspCoder.Kind() != reflect.Struct {
		logger.Instance().Printf("deviceType %d cmd %d reflect rspCoder TypeOf not struct", deviceType, cmd)
		rspCoder = nil
	}
	return reflect.New(rspCoder).Interface().(interface{}), nil
}
