package codec

import (
	"adasgitlab.autel.com/tools/cuav_proxy/entity/entity"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
)

func init() {

	//////////////////////////////组网协议///////////////////////////////////////////////////////////////////
	broadcast_req := &slinkv1.UdpBroadcastConfirmRequest{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.RadarUdpBroadcastResponse, broadcast_req)
	Instance().Register(entity.DEV_SCREEN, slinkv1.RadarUdpBroadcastResponse, broadcast_req)
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarUdpBroadcastResponse, broadcast_req)
	Instance().Register(entity.DEV_SFL100, slinkv1.RadarUdpBroadcastResponse, broadcast_req)
	Instance().Register(entity.DEV_AGX, slinkv1.RadarUdpBroadcastResponse, broadcast_req)
	//////////////////////////////哨兵塔 ///////////////////////////////////////////////////////////////////////////
	//心跳包
	heartSfl := &slinkv1.SflHeart{}
	Instance().Register(entity.DEV_SFL100, slinkv1.SflHeartMsg, heartSfl)

	detectSfl := &slinkv1.SflDetect{}
	Instance().Register(entity.DEV_SFL100, slinkv1.SflDetectMsg, detectSfl)
	// 设置打击点信息
	sfl_hitInfo := &slinkv1.SflSetHitInfoResponse{}
	Instance().Register(entity.DEV_SFL100, slinkv1.SflSetPith, sfl_hitInfo)
	// 设置打击角度
	sfl_angle := &slinkv1.SflSetHitAngleResponse{}
	Instance().Register(entity.DEV_SFL100, slinkv1.SflSetAngle, sfl_angle)
	// 设置水平转动
	sfl_horizontal := &slinkv1.SflHorizontalTurnResponse{}
	Instance().Register(entity.DEV_SFL100, slinkv1.SflHorizontalTurn, sfl_horizontal)
	// 设置垂直转动
	sfl_vertical := &slinkv1.SflVerticalTurnResponse{}
	Instance().Register(entity.DEV_SFL100, slinkv1.SflVerticalTurn, sfl_vertical)
	// 设置打击模式
	sfl_hitMode := &slinkv1.SflHitModeSetResponse{}
	Instance().Register(entity.DEV_SFL100, slinkv1.SflSetHitMode, sfl_hitMode)
	// SFL打击
	sfl_trunhit := &slinkv1.SflTurnHitResponse{}
	Instance().Register(entity.DEV_SFL100, slinkv1.SflHitTurn, sfl_trunhit)
	// SFL设置自动打击
	sfl_setAutohit := &slinkv1.SflSetAutoHitResponse{}
	Instance().Register(entity.DEV_SFL100, slinkv1.SflSetAutoHitMode, sfl_setAutohit)
	// SFL获取自动打击
	sfl_getAutohit := &slinkv1.SflGetAutoHitResponse{}
	Instance().Register(entity.DEV_SFL100, slinkv1.SflGetAutoHitMode, sfl_getAutohit)
	// SFL选中无人机打击
	sfl_SelectUavHit := &slinkv1.SflSendHitUavResponse{}
	Instance().Register(entity.DEV_SFL100, slinkv1.SflSendHitUav, sfl_SelectUavHit)
	// SFL定向无人机
	sfl_DirectUavHit := &slinkv1.SflSendDirectUavResponse{}
	Instance().Register(entity.DEV_SFL100, slinkv1.SflSendDirectUav, sfl_DirectUavHit)

	//////////////////////////////雷达 ///////////////////////////////////////////////////////////////////////////
	// 心跳包
	radar_heart := &slinkv1.RadarHeartbeat{}
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarIdHeartbeat, radar_heart)
	// 设置系统状态
	radar_system := &slinkv1.RadarSetSystemStatusResponse{}
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarIdSetSystemStatus, radar_system)
	// 获取系统状态
	radar_get_system_rsp := &slinkv1.RadarGetSystemInfoResponse{}
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarIdGetSystemInfo, radar_get_system_rsp)
	// 设置序列号
	radar_sn := &slinkv1.RadarSetSnResponse{}
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarIdSetSn, radar_sn)
	// 获取通讯加密密钥
	radar_secret := &slinkv1.RadarGetCommSecretResponse{}
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarIdGetCryptKey, radar_secret)
	// 设置WIFI断开连接
	radar_wifi := &slinkv1.RadarSetWifiConnResponse{}
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarIdSetWifiDisConn, radar_wifi)
	// 上传WIFI连接状态
	radar_upload_wifi := &slinkv1.RadarUploadWifiStatus{}
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarIdUploadWifiStatus, radar_upload_wifi)
	// 设置信息上报方式
	radar_set_mod := &slinkv1.RadarSetUploadModeResponse{}
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarIdSetUploadMode, radar_set_mod)
	// 上传跟踪目标信息
	radar_track := &slinkv1.RadarUploadTrackInfoResponse{}
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarIdUploadTrackInfo, radar_track)
	// 上传姿态信息
	radar_posture := &slinkv1.RadarUploadPostureInfo{}
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarIdUploadPosture, radar_posture)
	// 上传波控信息
	radar_control := &slinkv1.RadarUploadControlInfo{}
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarIdUploadControlInfo, radar_control)
	// 获取波控配置信息
	radar_get_beam := &slinkv1.RadarGetBeamSteerResponse{}
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarIdGetBeamSteerInfo, radar_get_beam)
	// 上传跟踪目标信息
	radar_detect := &slinkv1.RadarStartDetectResponse{}
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarIdStartDetect, radar_detect)
	// 上传跟踪目标信息
	radar_end_detect := &slinkv1.RadarEndDetectResponse{}
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarIdEndDetect, radar_end_detect)
	// 波控范围设置
	radar_set_beam := &slinkv1.RadarSetBeamPosResponse{}
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarIdSetBeamSize, radar_set_beam)
	// 雷达姿态开始标定
	radar_calibration := &slinkv1.PostureCalibrationResponse{}
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarIdPostureCalibration, radar_calibration)
	// 雷达姿态校准结果
	radar_calibration_result := &slinkv1.PostureCalibrationResultResponse{}
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarIdPostureCalibrationResult, radar_calibration_result)
	// 雷达姿态手动校准数据
	radar_calibration_manual := &slinkv1.PostureCalibrationManualResponse{}
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarIdPostureCalibrationManual, radar_calibration_manual)
	// 获取版本信息
	radar_calibration_version := &slinkv1.GetVersionInfoResponse{}
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarIdGetVersionInfo, radar_calibration_version)
	// 获取日志列表
	radar_logs := &slinkv1.RadarGetLogListResponse{}
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarGetLogList, radar_logs)
	// 删除日志
	radar_del_log := &slinkv1.RadarDelLogResponse{}
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarDeleteLog, radar_del_log)
	// 系统复位
	radar_reset_system := &slinkv1.RadarResetSystemResponse{}
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarIdResetSystem, radar_reset_system)
	// 获取固件写入状态
	radar_write_status := &slinkv1.RadarGetUpdateWriteStatusResponse{}
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarIdGetUpdateWriteStatus, radar_write_status)
	// 请求固件升级
	radar_upgrade := &slinkv1.RadarRequestUpgradeResponse{}
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarIdRequestUpgrade, radar_upgrade)
	// 发送升级固件数据
	radar_send_upgrade := &slinkv1.RadarSendUpdatePkgResponse{}
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarIdSendUpdatePkg, radar_send_upgrade)
	// 校验固件镜像
	radar_verify := &slinkv1.RadarVerifyImageResponse{}
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarIdVerifyImage, radar_verify)
	// 获取运行超时重试时间
	radar_timeout := &slinkv1.RadarGetUpdateTimeoutRetryTimeResponse{}
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarIdGetTimeoutRetryTime, radar_timeout)
	// 获取运行超时重试时间
	radar_app := &slinkv1.RadarRunAppResponse{}
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarIdRunApp, radar_app)
	// 写入固件数据
	radar_write_upgrade := &slinkv1.RadarWriteUpdateDataResponse{}
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarIdWriteUpdateData, radar_write_upgrade)

	//////////////////////////Screen协议 ///////////////////////////////////////////////////////////

	/////////////////////////Tracer协议 ///////////////////////////////////////////////////////////
	heart := &slinkv1.DroneIDHeartbeat{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.DRONEIDMsgHeartbeat, heart)

	detect := &slinkv1.TracerDetectResult{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.TracerIdGetDetectRes, detect)

	hideMode := &slinkv1.TracerSetHideModeResult{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.TracerSetHideMode, hideMode)

	whiteList := &slinkv1.TracerWhiteListResult{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.TracerSetWhiteList, whiteList)

	alarm := &slinkv1.TracerAlarmModeResult{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.TracerSetAlarmLevel, alarm)

	tracer_detect := &slinkv1.TracerDetectResult{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.TracerIdGetDetectRes, tracer_detect)

	remote_detect := &slinkv1.TracerRemoteDetectResult{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.TracerIdGetRemoteIdDetectRes, remote_detect)

	freq_detect := &slinkv1.TracerFreqDetectResult{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.TracerIdGetFreqDetectRes, freq_detect)

	drone_remote_detect := &slinkv1.TracerDetectDroneIdRemoteIdResult{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.TracerIdGetDronIdRemoteIdDetectRes, drone_remote_detect)

	freq_detectexp := &slinkv1.TracerSFreqDetectExp{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.TracerIdGetFreqDetectResExp, freq_detectexp)

	version := &slinkv1.TracerGetVersionResponse{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.TracerIdGetVersionInfo, version)
	//上位机请求固件升级
	upgrade := &slinkv1.TracerRequestUpgradeResponse{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.TracerIdRequestUpgrade, upgrade)
	// 上位机下载固件数据
	update := &slinkv1.TracerSendUpdatePkgResponse{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.TracerIdSendUpdatePkg, update)
	// 上位机请求校验固件数据
	verify := &slinkv1.TracerVerifyImageResponse{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.TracerIdVerifyImage, verify)
	// 上位机请求获取超时时间
	timeout := &slinkv1.TracerGetUpdateTimeoutRetryTimeResponse{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.TracerIdGetTimeoutRetryTime, timeout)
	// 上位机请求写入固件数据
	write := &slinkv1.TracerWriteUpdateDataResponse{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.TracerIdWriteUpdateData, write)
	// 上位机获取固件写入状态
	writeStatus := &slinkv1.TracerGetUpdateWriteStatusResponse{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.TracerIdGetUpdateWriteStatus, writeStatus)
	//上位机请求运行APP固件
	app := &slinkv1.TracerRunAppResponse{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.TracerIdRunApp, app)
	// 获取工作模式
	workMode := &slinkv1.TracerGetWorkModeResponse{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.TracerGetWorkMode, workMode)
	// 设置进入定向模式
	setMode := &slinkv1.TracerSetOrientationModeResponse{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.TracerSetOrientationMode, setMode)
	// CLI命令
	cli := &slinkv1.TracerCliResponse{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.TracerCliSend, cli)
	// 获取日志列表
	getLogs := &slinkv1.DroneIdGetLogListResponse{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.TracerIdGetLogList, getLogs)
	// 删除日志
	delLog := &slinkv1.DroneIdDelLogResponse{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.TracerIdGetLogList, delLog)
	// 获取时间信息
	time := &slinkv1.DroneIdGetTimeResponse{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.TracerIdGetLogList, time)
	// 设置定向
	rsp := &slinkv1.TracerProSetOrientResponse{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.TracerProSetOrient, rsp)
	// 设置噪底
	baseNoise := &slinkv1.TracerSetBaseNoiseResponse{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.TracerSetNoiseFloor, baseNoise)
	// 设置视频参数
	videoParam := &slinkv1.TracerSetVideParamResponse{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.TracerSetVideoParam, videoParam)
	//下发命令
	cliCmd := &slinkv1.TracerCliResponse{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.TracerCliSend, cliCmd)
	//上报wifi detect
	wifiDetect := &slinkv1.TracerProDetectWifiReport{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.TracerProWifiDetectReport, wifiDetect)
	// 上报 噪底侦测
	tracerBaseNoiseDetect := &slinkv1.TracerBaseNoiseDetectReport{}
	Instance().Register(entity.DEV_V2DRONEID, slinkv1.TracerSBaseNoiseReport, tracerBaseNoiseDetect)

}
