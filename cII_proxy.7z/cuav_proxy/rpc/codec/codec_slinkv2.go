package codec

import (
	"adasgitlab.autel.com/tools/cuav_proxy/entity/entity"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/generatecode/golang/bizproto"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2/msgid"
)

func init() {
	//////////////////////////////组网协议///////////////////////////////////////////////////////////////////
	broadcast_req := &bizproto.UdpBroadcastConfirmReq{}
	Instance().Register(entity.DEV_RADAR, slinkv1.RadarUdpBroadcastResponse, broadcast_req)

	radar_V2BeamSchedue := &bizproto.RadarBeamScheduling{}
	Instance().Register(entity.DEV_RADAR, msgid.RadarIdV2BeamScheduling, radar_V2BeamSchedue)

	radar_V2State := &bizproto.RadarState{}
	Instance().Register(entity.DEV_RADAR, msgid.RadarIdV2State, radar_V2State)

	radar_V2Detect := &bizproto.RadarDetect{}
	Instance().Register(entity.DEV_RADAR, msgid.RadarIdV2Detect, radar_V2Detect)

	radar_V2DotCohe := &bizproto.RadarDotCohe{}
	Instance().Register(entity.DEV_RADAR, msgid.RadarIdV2DotCohe, radar_V2DotCohe)

	radar_V2Track := &bizproto.RadarTrack{}
	Instance().Register(entity.DEV_RADAR, msgid.RadarIdV2Track, radar_V2Track)

	radar_V2SetBeamSchedule := &bizproto.RadarSetBeamSchedulingRsp{}
	Instance().Register(entity.DEV_RADAR, msgid.RadarIdV2SetBeamScheduling, radar_V2SetBeamSchedule)

	radar_V2SetConfig := &bizproto.RadarConfigRsp{}
	Instance().Register(entity.DEV_RADAR, msgid.RadarIdV2SetConfig, radar_V2SetConfig)

	radar_V2GetConfig := &bizproto.RadarReadConfigRsp{}
	Instance().Register(entity.DEV_RADAR, msgid.RadarIdV2GetConfig, radar_V2GetConfig)

	radar_V2SetSetting := &bizproto.RadarSetRsp{}
	Instance().Register(entity.DEV_RADAR, msgid.RadarIdV2SetSetting, radar_V2SetSetting)

	radar_V2SetAttitudeLLA := &bizproto.RadarSetAttitudeLLARsp{}
	Instance().Register(entity.DEV_RADAR, msgid.RadarIdV2SetAttitudeLLA, radar_V2SetAttitudeLLA)
}
