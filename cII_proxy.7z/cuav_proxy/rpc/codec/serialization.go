package codec

import (
	"errors"
)

// Serializer 编解码接口
type Serializer interface {
	// Marshal 序列化
	Marshal(v interface{}) ([]byte, error)
	// Unmarshal 反序列化
	Unmarshal(data []byte, v interface{}) error
}

const (
	// SerializationTypeUnkown 未知类型
	SerializationTypeUnkown uint32 = 0
	// SerializationTypeSlink Slink V1协议
	SerializationTypeSlink uint32 = 1
	// SerializationTypePB Slink V2协议，数据为PB格式
	SerializationTypePB uint32 = 2
)

var serializers = make(map[uint32]Serializer)

// RegisterSerializer 注册序列化器
func RegisterSerializer(serializationType uint32, s Serializer) {
	serializers[serializationType] = s
}

// GetSerializer 获取序列化器
func GetSerializer(serializationType uint32) Serializer {
	return serializers[serializationType]
}

// Marshal 序列化
func Marshal(serializationType uint32, body interface{}) ([]byte, error) {
	if body == nil {
		return nil, nil
	}
	s := GetSerializer(serializationType)
	if s == nil {
		return nil, errors.New("serializer not registered")
	}
	return s.Marshal(body)
}

// Unmarshal 反序列化
func Unmarshal(serializationType uint32, in []byte, body interface{}) error {
	if body == nil {
		return nil
	}
	if len(in) == 0 {
		return nil
	}
	s := GetSerializer(serializationType)
	if s == nil {
		return errors.New("serializer not registered")
	}
	return s.Unmarshal(in, body)
}
