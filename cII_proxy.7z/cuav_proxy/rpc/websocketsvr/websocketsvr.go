package websocketsvr

import (
	"fmt"
	"net/http"

	"adasgitlab.autel.com/tools/cuav_proxy/entity/logger"
	"github.com/gin-gonic/gin"
)

type WebSocketSvr struct {
	ip       string
	port     int
	handles  map[string]gin.HandlerFunc //http handles
	wHandles map[string]gin.HandlerFunc //websocket handles
}

type WebSocketSvrOpt func(w *WebSocketSvr)

// WithIP 设置IP
func WithIP(ip string) WebSocketSvrOpt {
	return func(w *WebSocketSvr) {
		w.ip = ip
	}
}

// WithPort 设置端口
func WithPort(port int) WebSocketSvrOpt {
	return func(w *WebSocketSvr) {
		w.port = port
	}
}

// WithWebHook 设置回调
func WithWebHook(http_hooks, websocket_hook map[string]gin.HandlerFunc) WebSocketSvrOpt {
	return func(w *WebSocketSvr) {
		w.handles = http_hooks
		w.wHandles = websocket_hook
	}
}

// NewWebSocketSvr 构造websocket服务
func NewWebSocketSvr(opts ...WebSocketSvrOpt) *WebSocketSvr {
	svr := &WebSocketSvr{}
	for _, opt := range opts {
		opt(svr)
	}
	return svr
}

// Start 启动webscoket
func (w *WebSocketSvr) Start() error {
	r := gin.Default()
	for k, v := range w.handles {
		r.POST(k, v)
	}
	for k, v := range w.wHandles {
		r.GET(k, v)
	}
	server := &http.Server{
		Addr:    fmt.Sprintf("%s:%d", w.ip, w.port),
		Handler: r,
	}
	if err := server.ListenAndServe(); err != nil {
		logger.Instance().Printf("http ListenAndServe err %v", err)
		return err
	}
	return nil
}
