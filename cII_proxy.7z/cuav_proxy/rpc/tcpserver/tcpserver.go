package tcpserver

import (
	"context"
	"fmt"
	"io"
	"net"
	"strconv"

	"adasgitlab.autel.com/tools/cuav_proxy/entity/entity"
	"adasgitlab.autel.com/tools/cuav_proxy/entity/logger"
	"adasgitlab.autel.com/tools/cuav_proxy/rpc/cmdhandler"
	"adasgitlab.autel.com/tools/cuav_proxy/rpc/codec"
	"adasgitlab.autel.com/tools/cuav_proxy/rpc/connmgr"
	"adasgitlab.autel.com/tools/cuav_proxy/rpc/task"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
	"adasgitlab.autel.com/tools/slink_proto/slinkv2"
)

var (
	maxRecvSize            = 1024 * 16
	TcpChannelPort     int = 8060
	TcpServerNormal    int = 1
	TcpServerNoDevConn int = 2
)

// TCPServer ...
type TCPServer struct {
	IP     string
	Port   int
	Sn     string   // 设备SN
	status int      // 连接状态，无设备连接主动关闭
	ch     chan int // 检测连接状态channel
}

// TcpServerOpt ...
type TcpServerOpt func(t *TCPServer)

// WithIP 设置IP
func WithIP(ip string) TcpServerOpt {
	return func(t *TCPServer) {
		t.IP = ip
	}
}

// WithPort 设置端口
func WithPort(port int) TcpServerOpt {
	return func(t *TCPServer) {
		t.Port = port
	}
}

// WithSn 设置Server对应的sn
func WithSn(sn string) TcpServerOpt {
	return func(t *TCPServer) {
		t.Sn = sn
	}
}

// NewTcpServer 创建TCP服务端
func NewTcpServer(opts ...TcpServerOpt) *TCPServer {
	server := &TCPServer{}
	for _, opt := range opts {
		opt(server)
	}
	return server
}

// Start 服务端启动
func (t *TCPServer) Start() {
	listener, err := net.Listen("tcp", t.ipString())
	if err != nil {
		logger.Instance().Printf("tcp server listen err: %v", err)
		return
	}
	defer listener.Close()
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	logger.Instance().Printf("tcp server start: %s", t.ipString())
	go func() {
		status := <-t.ch
		if status == TcpServerNoDevConn {
			listener.Close()
		}
	}()
	t.status = TcpServerNormal
	for {
		conn, err := listener.Accept()
		if err != nil {
			logger.Instance().Printf("tcp server accept err: %v", err)
			if t.status != TcpServerNormal {
				return
			}
			break
		}
		logger.Instance().Printf("tcp listen conn: %s", conn.RemoteAddr().String())
		// 设置设备对应的连接
		//if t.Sn != "STP100B00P531032" {
		//	break
		//}
		if err = connmgr.ConnectMgrInstance().SetConn(t.Sn, &connmgr.DevConn{Conn: conn}); err != nil {
			logger.Instance().Printf("sn %s SetConn err %v", t.Sn, err)
		}

		buff := make([]byte, 0)
		for {
			tmpBuff := make([]byte, maxRecvSize)
			n, err := conn.Read(tmpBuff)
			if err != nil {
				// 通常遇到的错误是连接中断或被关闭，用io.EOF表示
				if err == io.EOF {
					logger.Instance().Printf("tcp conn receive close: %v", conn.RemoteAddr())
				} else {
					logger.Instance().Printf("tcp conn receive err:%v", err)
				}
				if err := conn.Close(); err != nil {
					logger.Instance().Printf("conn remote addr %s close err %v", conn.RemoteAddr().String(), err)
				}
				if err := connmgr.ConnectMgrInstance().DelConn(t.Sn); err != nil {
					logger.Instance().Printf("ConnectMgrInstance DelConn err %v", err)
				}
				break
			}
			if n <= 0 {
				continue
			}
			logger.Instance().Printf("tcp recv from [%s] buff [% x]", conn.RemoteAddr().String(), tmpBuff[:n])
			buff = append(buff, tmpBuff[:n]...)
			// SlinkV1/V2都不是，需要继续收包
			if !slinkv1.IsSlinkV1(buff) && !slinkv2.IsSlinkV2(buff) {
				continue
			}
			leftBuff := make([]byte, 0)
			if slinkv1.IsSlinkV1(buff) {
				leftBuff, err = t.handleSlinkV1(ctx, conn, buff)
				if err != nil {
					logger.Instance().Printf("HandleSlinkV1 err: %v", err)
				}
			}
			if slinkv2.IsSlinkV2(buff) {
				leftBuff, err = t.handleSlinkV2(ctx, conn, buff)
				if err != nil {
					logger.Instance().Printf("HandleSlinkV2 err: %v", err)
				}
			}
			buff = buff[:0]
			if len(leftBuff) > 0 {
				buff = append(buff, leftBuff...)
			}
		}
	}
}

// Stop 服务端停止
func (t *TCPServer) Stop() {
	logger.Instance().Printf("stop tcp:%s", t.ipString())
	if t.status != TcpServerNoDevConn {
		t.status = TcpServerNoDevConn
		t.ch <- TcpServerNoDevConn
		close(t.ch)
		// Todo:设备对应的连接是否需要关闭
	}
}

// ipString
func (t *TCPServer) ipString() string {
	return net.JoinHostPort(t.IP, fmt.Sprint(t.Port))
}

func (t *TCPServer) handleSlinkV1(ctx context.Context, conn net.Conn, buff []byte) ([]byte, error) {
	packets, leftBuff, err := slinkv1.ParseMavlinkBuff(buff)
	if err != nil {
		logger.Instance().Printf("DealReciveBuff err %v", err)
	}
	logger.Instance().Printf("tcp read from [%s] packets len:%d left buff len %d value % x", conn.RemoteAddr().String(), len(packets), len(leftBuff), leftBuff)
	for index, rsp := range packets {
		go func(sn string, index int, rsp *slinkv1.MavPacket) {
			logger.Instance().Printf("handle packet index %d req head %+v data[% x]", index, rsp.Header, rsp.PayLoad)
			rspBody, err := codec.Instance().Get(entity.DeviceType(rsp.GetSourceID()), uint16(rsp.GetMsgID()))
			if err != nil {
				logger.Instance().Printf("packet index %d GetCodec err %v devtype %d cmd %d", index, err, rsp.GetSourceID(), rsp.GetMsgID())
				return
			}
			if rspBody == nil {
				logger.Instance().Printf("packet index %d devtype %d cmd %d RspCodec nil", index, rsp.GetSourceID(), rsp.GetMsgID())
				return
			}
			if err := codec.Unmarshal(codec.SerializationTypeSlink, rsp.PayLoad, rspBody); err != nil {
				logger.Instance().Printf("rsp Decode err %v", err)
				return
			}
			handle, err := cmdhandler.Instance().GetHandler(entity.DeviceType(rsp.GetSourceID()), uint16(rsp.GetMsgID()))
			if err != nil {
				logger.Instance().Printf("packet index %d Get cmd Handle err %v, header %+v", index, err, rsp.Header)
				return
			}
			buRsp, err := handle(ctx, sn, rspBody)
			if err != nil {
				logger.Instance().Printf("packet index %d packet Handler err %v", index, err)
				return
			}
			if buRsp == nil {
				logger.Instance().Printf("buRsp nil sn %s seq %d msgid %X task Finished", sn, rsp.GetSeq(), rsp.GetMsgID())
				return
			}
			t := task.NewTask(task.WithID(strconv.Itoa(int(rsp.GetSeq()))), task.WithResult(buRsp))
			if err := task.TaskMgrInstance().Finish(sn, uint16(rsp.GetMsgID()), t); err != nil {
				logger.Instance().Printf("sn %s seq %d msgid %X task Finished", sn, rsp.GetSeq(), rsp.GetMsgID())
				return
			}
		}(t.Sn, index, rsp)
	}
	return leftBuff, nil
}

func (t *TCPServer) handleSlinkV2(ctx context.Context, conn net.Conn, buff []byte) ([]byte, error) {
	packets, leftBuff, err := slinkv2.ParseMavlinkBuff(buff)
	if err != nil {
		logger.Instance().Printf("DealReciveBuff err %v", err)
	}
	logger.Instance().Printf("tcp read from [%s] packets len:%d left buff len %d value % x", conn.RemoteAddr().String(), len(packets), len(leftBuff), leftBuff)
	for index, rsp := range packets {
		go func(sn string, index int, rsp *slinkv2.PacketV2) {
			logger.Instance().Printf("handle packet index %d req head %+v data[% x]", index, rsp.Header, rsp.PayLoad)
			rspBody, err := codec.Instance().Get(entity.DeviceType(rsp.GetSourceID()), uint16(rsp.GetMsgID()))
			if err != nil {
				logger.Instance().Printf("packet index %d GetCodec err %v devtype %d cmd %d", index, err, rsp.GetSourceID(), rsp.GetMsgID())
				return
			}
			if rspBody == nil {
				logger.Instance().Printf("packet index %d devtype %d cmd %d RspCodec nil", index, rsp.GetSourceID(), rsp.GetMsgID())
				return
			}
			if err := codec.Unmarshal(codec.SerializationTypePB, rsp.PayLoad, rspBody); err != nil {
				logger.Instance().Printf("req Decode err %v", err)
				return
			}
			handle, err := cmdhandler.Instance().GetHandler(entity.DeviceType(rsp.GetSourceID()), uint16(rsp.GetMsgID()))
			if err != nil {
				logger.Instance().Printf("packet index %d Get cmd Handle err %v, header %+v", index, err, rsp.Header)
				return
			}
			buRsp, err := handle(ctx, sn, rspBody)
			if err != nil {
				logger.Instance().Printf("packet index %d packet Handler err %v", index, err)
				return
			}
			if buRsp == nil {
				logger.Instance().Printf("buRsp nil sn %s seq %d msgid %X task Finished", sn, rsp.GetSeq(), rsp.GetMsgID())
				return
			}
			t := task.NewTask(task.WithID(strconv.Itoa(int(rsp.GetSeq()))), task.WithResult(buRsp))
			if err := task.TaskMgrInstance().Finish(sn, uint16(rsp.GetMsgID()), t); err != nil {
				logger.Instance().Printf("sn %s seq %d msgid %X task Finished", sn, rsp.GetSeq(), rsp.GetMsgID())
				return
			}
		}(t.Sn, index, rsp)
	}
	return leftBuff, nil
}
