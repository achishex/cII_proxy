package webclient

import (
	"adasgitlab.autel.com/tools/cuav_proxy/entity/logger"

	"github.com/gorilla/websocket"
	uuid "github.com/satori/go.uuid"
	"go.uber.org/ratelimit"
)

var MaxNumPerSecond = 5 //每秒x次，限速

type Client struct {
	id          string //连接唯一id
	data        chan []byte
	conn        *websocket.Conn
	ratelimiter ratelimit.Limiter //限速器
}

type ClientOpt func(c *Client)

// WithConn 设置连接
func WithConn(conn *websocket.Conn) ClientOpt {
	return func(c *Client) {
		c.conn = conn
	}
}

func WithClientID(id string) ClientOpt {
	return func(c *Client) {
		c.id = id
	}
}
func NewClient(opts ...ClientOpt) *Client {
	client := &Client{
		data: make(chan []byte),
		id:   uuid.NewV4().String(),
		//ratelimiter: ratelimit.New(MaxNumPerSecond),
	}
	for _, opt := range opts {
		opt(client)
	}
	return client
}

// Read 读取websocket数据
func (c *Client) Read() {
	defer func() {
		ClientMgrInstance().UnRegister(c)
		_ = c.conn.Close()
	}()
	for {
		_, msg, err := c.conn.ReadMessage()
		if err != nil {
			logger.Instance().Printf("Failed to read message from webSocket remoteip[%s] err %v", c.conn.RemoteAddr().String(), err)
			break
		}
		c.data <- msg
	}
}

// Send 发送数据
func (c *Client) Write() {
	defer func() {
		ClientMgrInstance().UnRegister(c)
		_ = c.conn.Close()
	}()
	// 发送通道数据
	for msg := range c.data {
		//	_ = c.ratelimiter.Take()
		if err := c.conn.WriteMessage(websocket.TextMessage, msg); err != nil {
			logger.Instance().Printf("Failed to write message from websocket remoteip[%s] err %v", c.conn.RemoteAddr().String(), err)
		}

	}
}
