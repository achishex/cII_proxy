package connmgr

import (
	"net"
	"sync"

	"adasgitlab.autel.com/tools/cuav_proxy/entity/logger"
)

// DevConn 设备连接信息
type DevConn struct {
	Conn net.Conn
}

// ConnectMgr 设备管理
type ConnectMgr struct {
	mu       sync.Mutex
	DevConns map[string]*DevConn
}

var (
	connMgrInstance *ConnectMgr
	connOnce        sync.Once
)

// ConnectMgrInstance 连接管理单例
func ConnectMgrInstance() *ConnectMgr {
	connOnce.Do(func() {
		connMgrInstance = &ConnectMgr{
			DevConns: make(map[string]*DevConn),
		}
	})
	return connMgrInstance
}

// GetConn 获取连接
func (c *ConnectMgr) GetConn(sn string) *DevConn {
	c.mu.Lock()
	defer c.mu.Unlock()
	if v, ok := c.DevConns[sn]; ok {
		return v
	}
	return nil
}

// SetConn 设置连接
func (c *ConnectMgr) SetConn(sn string, conn *DevConn) error {
	logger.Instance().Printf("SetConn sn %s conn %s", sn, conn.Conn.RemoteAddr().String())
	c.mu.Lock()
	defer c.mu.Unlock()
	c.DevConns[sn] = conn
	return nil
}

// UpdateConn 更新连接
func (c *ConnectMgr) UpdateConn(sn string, conn *DevConn) error {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.DevConns[sn] = conn
	return nil
}

// DelConn 删除连接
func (c *ConnectMgr) DelConn(sn string) error {
	logger.Instance().Printf("DelConn sn %s ", sn)
	c.mu.Lock()
	defer c.mu.Unlock()
	delete(c.DevConns, sn)
	return nil
}

func (c *ConnectMgr) GetSNList() []string {
	c.mu.Lock()
	defer c.mu.Unlock()

	snList := make([]string, 0, len(c.DevConns))
	for sn := range c.DevConns {
		snList = append(snList, sn)
	}
	return snList
}
