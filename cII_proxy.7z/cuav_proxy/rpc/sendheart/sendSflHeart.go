package sendheart

import (
	"adasgitlab.autel.com/tools/cuav_proxy/entity/entity"
	"adasgitlab.autel.com/tools/cuav_proxy/entity/logger"
	"adasgitlab.autel.com/tools/cuav_proxy/rpc/connmgr"
	"adasgitlab.autel.com/tools/cuav_proxy/rpc/devicerpc"
	"adasgitlab.autel.com/tools/slink_proto/slinkv1"
	"strings"
	"time"
)

var (
	SflHeartSum uint8
)

func SendSflHeart() {
	tick := time.NewTicker(1 * time.Second)
	defer tick.Stop()
	//defer func() {
	//	if r := recover(); r != nil {
	//		err := fmt.Errorf("panic: %v", r)
	//		logger.Instance().Printf("panic:", err)
	//
	//	}
	//}()
	for {
		select {
		case <-tick.C:
			SflHeartSum++
			if SflHeartSum > 255 {
				SflHeartSum = 0
			}
			req := &slinkv1.SflHeartbeatExtRequest{
				SflHeartSum,
			}
			snList := connmgr.ConnectMgrInstance().GetSNList()
			for _, s := range snList {
				if strings.Contains(s, "SFL") {
					_, err := devicerpc.CallOnlySend(s, entity.DEV_SFL100, slinkv1.C2SendHeartbeatToSfl, req)
					if err != nil {
						logger.Instance().Printf("C2SendHeartbeatToSfl rpc call err %v", err)
					}
				} else if strings.Contains(s, "agx") {
					_, err := devicerpc.CallOnlySend(s, entity.DEV_AGX, slinkv1.C2SendHeartbeatToSfl, req)
					if err != nil {
						logger.Instance().Printf("C2SendHeartbeatToSfl rpc call err %v", err)
					}
				}

			}
			logger.Instance().Printf("---------->send Heart ")
		}
	}

}
