package main

import (
	"adasgitlab.autel.com/tools/cuav_proxy/api"
	"adasgitlab.autel.com/tools/cuav_proxy/entity/logger"
	"adasgitlab.autel.com/tools/cuav_proxy/logic/broadcast"
	"adasgitlab.autel.com/tools/cuav_proxy/rpc/discovery"
	"adasgitlab.autel.com/tools/cuav_proxy/rpc/sendheart"
	"adasgitlab.autel.com/tools/cuav_proxy/rpc/websocketsvr"
	"github.com/gin-gonic/gin"
	_ "net/http/pprof"
)

// Init ...
func Init() error {
	//启动自动组网能力
	go discovery.Instance(discovery.WithHandler(broadcast.HandleDiscovery)).Start()
	go sendheart.SendSflHeart()
	return nil
}

// StartAPIServer ...
func StartAPIServer() error {
	httpRoutes := map[string]gin.HandlerFunc{
		"/device/tracer/set-orientation-mode":    api.SetTracerWorkMode,
		"/device/radar/get-system-info":          api.GetRadarSystemInfo,
		"/device/radar/set-system-status":        api.SetRadarSystemInfo,
		"/device/tracer/get-work-mode":           api.GetTracerWorkMode,
		"/device/tracer/set-whitelist-alarm":     api.TracerWhiteList,
		"/device/tracer/set-alarm":               api.TracerSetAlarm,
		"/device/tracer/set-hide-mode":           api.TracerSetHide,
		"/device/tracerPro/set-orientation-mode": api.TracerProSetOrient,
		"/device/tracer/set-video-param":         api.TracerSetVideoParam,
		"/device/tracer/set-noise-floor":         api.TracerSetNoiseFloor,
		"/device/tracer/cli":                     api.TracerSendCmd,

		//Sfl
		"/device/sfl/hit-angle":       api.SflHitAngle,
		"/device/sfl/horizontal-turn": api.SflHorizontalTurn,
		"/device/sfl/vertical-turn":   api.SflVerticalTurn,
		"/device/sfl/hit-mode-set":    api.SflHitModeSet,
		"/device/sfl/turn-hit":        api.SflTurnHit,
		"/device/sfl/set-auto-hit":    api.SflSetAutoHit,
		"/device/sfl/get-auto-hit":    api.SflGetAutoHit,
		"/device/sfl/select-uav-hit":  api.SflSelectUavHit,
		"/device/sfl/direct-uav":      api.SflDirectUav,

		/// radar v2 http api
		"/device/radar/set/beam-scheduling": api.SetBeamScheduling,
		"/device/radar/set/config":          api.SetRadarConfig,
		"/device/radar/set/setting":         api.SetRadarSetting,
		"/device/radar/set/attitude-lla":    api.SetRadarAttitudeLLA,
	}
	websocketRoutes := map[string]gin.HandlerFunc{
		"/ws/v1/report": api.ReportDeviceInfo,

		/// radar v2 websocket api
		"/ws/radar/v2": api.RadarWs,
	}
	if err := websocketsvr.NewWebSocketSvr(websocketsvr.WithIP("0.0.0.0"), websocketsvr.WithPort(1860),
		websocketsvr.WithWebHook(httpRoutes, websocketRoutes)).Start(); err != nil {
		logger.Instance().Printf("webscoketsvr Start err %v", err)
		return err
	}
	return nil
}

func main() {
	if err := Init(); err != nil {
		logger.Instance().Printf("Init err %v", err)
		panic(err)
	}
	if err := StartAPIServer(); err != nil {
		logger.Instance().Printf("StartAPIServer err %v", err)
		panic(err)
	}
}
